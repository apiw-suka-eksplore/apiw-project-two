# PROJECT: LAST SURVIVOR (Project Rafi Suka Perang)

Offline 3D Battle Royale Survival Game for Android built with Kotlin, Jetpack Compose, and procedural 3D rasterization rendering.

## Overview
- **Game Title**: Project: Last Survivor
- **Mode**: Solo Battle Royale (1 Player vs 19 AI Bots, configurable up to 35)
- **Engine / Architecture**: Android Native with Compose 3D Canvas Projection Engine and MVVM Architecture (`BattleRoyaleEngine.kt`).
- **Network Requirement**: 100% Offline. All combat, AI bots, currency, unlocks, progression, and settings persist locally without any remote server requirement.

## Key Features
1. **Interactive 3D Lobby & Character Showcase**:
   - 3D pedestal showcase with touch drag yaw rotation.
   - Dynamic player profile (Level, EXP bar, Gold, Diamond balances).
   - Instant deployment into combat arena.

2. **Full Battle Royale Combat System**:
   - 6 Weapon Types: Assault Rifle (M4A1), Submachine Gun (MP5), Shotgun (M1014), Sniper Rifle (AWM), Pistol (Desert Eagle), and Katana.
   - Distinct weapon statistics: fire rates, magazine size, reserve ammo, reload duration, bullet spread, recoil, and headshot multipliers (2.0x - 2.5x).
   - Aim-Down-Sights (ADS) precision targeting mode.
   - Real-time hitmarkers with critical headshot indicators.

3. **Gloo Wall Tactical Defense System**:
   - Deployable holographic shields placed in front of combatants.
   - Intercepts enemy fire, provides cover, blocks line-of-sight and movement.
   - Used intelligently by bot AI during intense firefights.

4. **Autonomous Offline Bot AI**:
   - 4 Configurable difficulty tiers: Easy Cadet, Normal Soldier, Hard Veteran, Extreme Apex.
   - Multi-state finite state machine: Patrol, Looting, Engaging, Taking Cover, Flanking, Healing, Deploying Gloo Wall, and Safe Zone navigation.
   - Realistic reaction delays, accuracy spread, and distance-based tick optimization.

5. **Compact Battle Island Arena**:
   - Outposts, Armory buildings, bunkers, trees, rocks, and military crates.
   - Dynamic shrinking Safe Zone with damage ticks for outside combatants.
   - Field loot drops: Ammunition crates, Medkits, Armor vests, Gloo wall charges, and Weapon drops.

6. **Progression, Vault Shop & Economy**:
   - Currencies: Gold and Diamonds earned exclusively offline through gameplay and tactical directives.
   - Multiple operator suits with custom rarities (Common, Rare, Epic, Legendary).
   - Persistent local save system storing level, unlocks, equipped cosmetics, and stats.

7. **Comprehensive Graphics & Performance Controls**:
   - 7 Performance presets: Ultra Low, Super Smooth, Smooth, Balanced, Standard, High, Ultra.
   - Battery Saver, Real-time shadow toggle, Look sensitivity, and Audio volume sliders.
