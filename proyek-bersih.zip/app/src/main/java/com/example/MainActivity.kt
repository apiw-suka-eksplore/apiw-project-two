package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.engine.BattleRoyaleEngine
import com.example.ui.components.BattleArena3DRenderer
import com.example.ui.components.BattleHUD
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

enum class ScreenState {
    LOBBY,
    BATTLE,
    SHOP,
    MISSIONS,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private lateinit var gameEngine: BattleRoyaleEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        gameEngine = BattleRoyaleEngine(applicationContext)

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF090D16)
                ) {
                    LastSurvivorApp(engine = gameEngine)
                }
            }
        }
    }
}

@Composable
fun LastSurvivorApp(engine: BattleRoyaleEngine) {
    val gameState by engine.gameState.collectAsState()
    val progression by engine.progression.collectAsState()
    val graphicsSettings by engine.graphicsSettings.collectAsState()
    val audioSettings by engine.audioSettings.collectAsState()
    val controlSettings by engine.controlSettings.collectAsState()
    val missions by engine.missions.collectAsState()

    var currentScreen by remember { mutableStateOf(ScreenState.LOBBY) }

    // System Back Handler
    BackHandler(enabled = currentScreen != ScreenState.LOBBY || gameState.isMatchActive) {
        if (gameState.isMatchActive) {
            engine.endMatchAndReturnToLobby()
            currentScreen = ScreenState.LOBBY
        } else {
            currentScreen = ScreenState.LOBBY
        }
    }

    // Auto-switch to BATTLE screen if match becomes active
    LaunchedEffect(gameState.isMatchActive) {
        if (gameState.isMatchActive) {
            currentScreen = ScreenState.BATTLE
        } else if (currentScreen == ScreenState.BATTLE) {
            currentScreen = ScreenState.LOBBY
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF090D16))) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "screen_flow_transition"
        ) { screen ->
            when (screen) {
                ScreenState.LOBBY -> {
                    LobbyScreen(
                        progression = progression,
                        onStartMatch = { bots, diff ->
                            engine.startMatch(bots, diff)
                        },
                        onOpenShop = { currentScreen = ScreenState.SHOP },
                        onOpenMissions = { currentScreen = ScreenState.MISSIONS },
                        onOpenSettings = { currentScreen = ScreenState.SETTINGS }
                    )
                }

                ScreenState.BATTLE -> {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // 3D Battle Arena World Renderer
                        BattleArena3DRenderer(
                            player = gameState.player,
                            combatants = gameState.combatants,
                            glooWalls = gameState.glooWalls,
                            lootItems = gameState.lootItems,
                            safeZone = gameState.safeZone,
                            graphicsSettings = graphicsSettings,
                            muzzleFlashAlpha = gameState.muzzleFlashAlpha
                        )

                        // Battle Touch HUD overlay
                        BattleHUD(
                            gameState = gameState,
                            onMove = { normX, normZ -> engine.movePlayer(normX, normZ) },
                            onLook = { deltaX, deltaY -> engine.rotateCamera(deltaX, deltaY) },
                            onFire = { engine.firePlayerWeapon() },
                            onReload = { engine.reloadPlayerWeapon() },
                            onSwitchWeapon = { wp -> engine.switchWeapon(wp) },
                            onDeployGlooWall = { engine.deployGlooWall() },
                            onUseMedkit = { engine.useMedkit() },
                            onToggleADS = { engine.toggleADS() },
                            onToggleCrouch = { engine.toggleCrouch() },
                            onToggleSprint = { engine.toggleSprint() },
                            onPause = { engine.endMatchAndReturnToLobby() }
                        )

                        // Victory / Defeat Modal overlay
                        if (gameState.isGameOver && gameState.matchResult != null) {
                            MatchResultModal(
                                result = gameState.matchResult!!,
                                onPlayAgain = {
                                    engine.startMatch()
                                },
                                onReturnToLobby = {
                                    engine.endMatchAndReturnToLobby()
                                    currentScreen = ScreenState.LOBBY
                                }
                            )
                        }
                    }
                }

                ScreenState.SHOP -> {
                    ShopScreen(
                        progression = progression,
                        onPurchaseSkin = { skin -> engine.purchaseSkin(skin) },
                        onEquipSkin = { skinId -> engine.equipSkin(skinId) },
                        onBack = { currentScreen = ScreenState.LOBBY }
                    )
                }

                ScreenState.MISSIONS -> {
                    MissionsScreen(
                        missions = missions,
                        onClaimReward = { mId -> engine.claimMission(mId) },
                        onBack = { currentScreen = ScreenState.LOBBY }
                    )
                }

                ScreenState.SETTINGS -> {
                    SettingsScreen(
                        graphicsSettings = graphicsSettings,
                        audioSettings = audioSettings,
                        controlSettings = controlSettings,
                        onApplyPreset = { preset -> engine.applyGraphicsPreset(preset) },
                        onUpdateGraphics = { g -> engine.updateGraphicsSettings(g) },
                        onUpdateAudio = { a -> engine.updateAudioSettings(a) },
                        onUpdateControls = { c -> engine.updateControlSettings(c) },
                        onBack = { currentScreen = ScreenState.LOBBY }
                    )
                }
            }
        }
    }
}
