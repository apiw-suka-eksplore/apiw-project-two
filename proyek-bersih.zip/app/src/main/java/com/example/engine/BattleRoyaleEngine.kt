package com.example.engine

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.sound.GameSoundManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.*
import kotlin.random.Random

data class GameSessionState(
    val isMatchActive: Boolean = false,
    val isPaused: Boolean = false,
    val isGameOver: Boolean = false,
    val isVictory: Boolean = false,
    val matchResult: MatchResult? = null,
    val player: Combatant = Combatant("p1", "Survivor", true, Vec3(0f, 0f, 0f)),
    val combatants: List<Combatant> = emptyList(),
    val glooWalls: List<GlooWall> = emptyList(),
    val lootItems: List<LootItem> = emptyList(),
    val safeZone: SafeZone = SafeZone(),
    val aliveCount: Int = 20,
    val killFeed: List<String> = emptyList(),
    val recentHitmarker: HitmarkerEvent? = null,
    val matchDurationSec: Int = 0,
    val muzzleFlashAlpha: Float = 0f,
    val damageDirectionAngle: Float? = null,
    val glooWallCooldownSec: Float = 0f
)

class BattleRoyaleEngine(private val context: Context) : ViewModel() {

    private val _gameState = MutableStateFlow(GameSessionState())
    val gameState: StateFlow<GameSessionState> = _gameState.asStateFlow()

    private val _progression = MutableStateFlow(PlayerProgression())
    val progression: StateFlow<PlayerProgression> = _progression.asStateFlow()

    private val _graphicsSettings = MutableStateFlow(GraphicsSettings())
    val graphicsSettings: StateFlow<GraphicsSettings> = _graphicsSettings.asStateFlow()

    private val _audioSettings = MutableStateFlow(AudioSettings())
    val audioSettings: StateFlow<AudioSettings> = _audioSettings.asStateFlow()

    private val _controlSettings = MutableStateFlow(ControlSettings())
    val controlSettings: StateFlow<ControlSettings> = _controlSettings.asStateFlow()

    private val _missions = MutableStateFlow(GameContentRepository.initialMissions)
    val missions: StateFlow<List<DailyMission>> = _missions.asStateFlow()

    val soundManager = GameSoundManager(context)

    // Match configuration
    var selectedBotCount: Int = 19
    var selectedDifficulty: BotDifficulty = BotDifficulty.NORMAL

    private var matchLoopJob: Job? = null
    private var lastLoopTimeNanos: Long = 0L

    init {
        loadPersistedData()
    }

    private fun loadPersistedData() {
        val prefs = context.getSharedPreferences("last_survivor_data", Context.MODE_PRIVATE)
        val level = prefs.getInt("player_level", 4)
        val exp = prefs.getInt("player_exp", 640)
        val gold = prefs.getInt("player_gold", 3850)
        val diamonds = prefs.getInt("player_diamonds", 180)
        val matchesPlayed = prefs.getInt("matches_played", 14)
        val matchesWon = prefs.getInt("matches_won", 5)
        val totalKills = prefs.getInt("total_kills", 48)
        val equippedSkin = prefs.getString("equipped_skin", "skin_default") ?: "skin_default"
        val unlockedSkins = prefs.getStringSet("unlocked_skins", setOf("skin_default", "skin_desert_commando")) ?: setOf("skin_default")

        _progression.value = PlayerProgression(
            level = level,
            currentExp = exp,
            goldBalance = gold,
            diamondBalance = diamonds,
            matchesPlayed = matchesPlayed,
            matchesWon = matchesWon,
            totalKills = totalKills,
            equippedSkinId = equippedSkin,
            unlockedSkins = unlockedSkins
        )
    }

    private fun savePersistedData() {
        val prog = _progression.value
        context.getSharedPreferences("last_survivor_data", Context.MODE_PRIVATE).edit()
            .putInt("player_level", prog.level)
            .putInt("player_exp", prog.currentExp)
            .putInt("player_gold", prog.goldBalance)
            .putInt("player_diamonds", prog.diamondBalance)
            .putInt("matches_played", prog.matchesPlayed)
            .putInt("matches_won", prog.matchesWon)
            .putInt("total_kills", prog.totalKills)
            .putString("equipped_skin", prog.equippedSkinId)
            .putStringSet("unlocked_skins", prog.unlockedSkins)
            .apply()
    }

    fun startMatch(botCount: Int = selectedBotCount, difficulty: BotDifficulty = selectedDifficulty) {
        selectedBotCount = botCount
        selectedDifficulty = difficulty

        val player = Combatant(
            id = "player_1",
            name = _progression.value.playerName,
            isPlayer = true,
            position = Vec3(0f, 0f, 0f),
            yaw = 0f,
            pitch = 0f,
            health = 100f,
            armor = 50f,
            glooWallsCount = 3,
            medkitsCount = 2,
            currentWeapon = WeaponType.AR,
            currentWeaponState = WeaponState(WeaponType.AR),
            characterSkinId = _progression.value.equippedSkinId
        )

        val combatantsList = mutableListOf(player)

        // Spawn Bots in circle radius across the map
        val botNames = listOf(
            "ViperX", "ShadowSniper", "BlazeRider", "GhostRecon", "TitanFury",
            "RavenEdge", "StormBringer", "ZeroPoint", "CyborgAlpha", "FrostBite",
            "IronClad", "NovaStrike", "PulseHunter", "PhantomDrift", "BulletProof",
            "ApexPredator", "CrimsonWolf", "OmegaPrime", "ThunderHawk", "SilentEcho"
        )

        val availableSkins = GameContentRepository.characterSkins.map { it.id }

        for (i in 0 until botCount) {
            val angle = (2.0 * Math.PI * i / botCount).toFloat() + Random.nextFloat() * 0.2f
            val dist = Random.nextFloat() * 70f + 25f
            val x = cos(angle) * dist
            val z = sin(angle) * dist

            val bot = Combatant(
                id = "bot_${i + 1}",
                name = botNames.getOrElse(i) { "Bot #${i + 1}" },
                isPlayer = false,
                position = Vec3(x, 0f, z),
                yaw = Random.nextFloat() * 6.28f,
                health = 100f,
                armor = if (Random.nextBoolean()) 50f else 0f,
                glooWallsCount = Random.nextInt(1, 3),
                medkitsCount = Random.nextInt(1, 3),
                currentWeapon = WeaponType.values()[Random.nextInt(0, 5)],
                currentWeaponState = WeaponState(WeaponType.AR),
                characterSkinId = availableSkins.random()
            )
            bot.currentWeaponState = WeaponState(bot.currentWeapon)
            combatantsList.add(bot)
        }

        // Generate Loot across map
        val lootList = mutableListOf<LootItem>()
        for (i in 0 until 35) {
            val lx = Random.nextFloat() * 160f - 80f
            val lz = Random.nextFloat() * 160f - 80f
            val type = LootType.values().random()
            lootList.add(
                LootItem(
                    id = "loot_$i",
                    type = type,
                    position = Vec3(lx, 0f, lz),
                    amount = if (type == LootType.AMMO_AR) 30 else 1,
                    associatedWeapon = if (type == LootType.WEAPON_DROP) WeaponType.values().random() else null
                )
            )
        }

        val safeZone = SafeZone(
            centerX = 0f,
            centerZ = 0f,
            currentRadius = 135f,
            targetRadius = 85f,
            targetCenterX = Random.nextFloat() * 30f - 15f,
            targetCenterZ = Random.nextFloat() * 30f - 15f,
            phase = 1,
            timeRemainingSec = 40f,
            isShrinking = false
        )

        _gameState.value = GameSessionState(
            isMatchActive = true,
            isPaused = false,
            isGameOver = false,
            isVictory = false,
            player = player,
            combatants = combatantsList,
            glooWalls = emptyList(),
            lootItems = lootList,
            safeZone = safeZone,
            aliveCount = combatantsList.size,
            killFeed = listOf("Match started! 20 Survivors dropped."),
            matchDurationSec = 0
        )

        startMatchLoop()
    }

    private fun startMatchLoop() {
        matchLoopJob?.cancel()
        lastLoopTimeNanos = System.nanoTime()

        matchLoopJob = viewModelScope.launch {
            while (_gameState.value.isMatchActive && !_gameState.value.isGameOver) {
                val now = System.nanoTime()
                val dt = ((now - lastLoopTimeNanos) / 1_000_000_000.0).toFloat().coerceIn(0.016f, 0.1f)
                lastLoopTimeNanos = now

                if (!_gameState.value.isPaused) {
                    updateMatchTick(dt)
                }

                // Tick at ~30 FPS logic rate for battery and low-end CPU optimization
                delay(33)
            }
        }
    }

    private fun updateMatchTick(dt: Float) {
        val state = _gameState.value
        val player = state.player
        val combatants = state.combatants.toMutableList()
        val glooWalls = state.glooWalls.toMutableList()
        val lootItems = state.lootItems.toMutableList()
        val killFeed = state.killFeed.toMutableList()
        val safeZone = state.safeZone.copy()

        // 1. Safe Zone Shrink & Timer
        safeZone.timeRemainingSec -= dt
        if (safeZone.timeRemainingSec <= 0f) {
            if (!safeZone.isShrinking) {
                // Start shrinking phase
                safeZone.isShrinking = true
                safeZone.timeRemainingSec = safeZone.shrinkDurationSec.toFloat()
                killFeed.add(0, "⚠️ Safe zone is now shrinking!")
            } else {
                // Finished shrinking, advance phase
                safeZone.isShrinking = false
                safeZone.phase += 1
                safeZone.currentRadius = safeZone.targetRadius
                safeZone.centerX = safeZone.targetCenterX
                safeZone.centerZ = safeZone.targetCenterZ
                safeZone.targetRadius = max(18f, safeZone.currentRadius * 0.65f)
                safeZone.targetCenterX += (Random.nextFloat() - 0.5f) * 20f
                safeZone.targetCenterZ += (Random.nextFloat() - 0.5f) * 20f
                safeZone.timeRemainingSec = 35f
                safeZone.damagePerSec += 2.5f
                killFeed.add(0, "Zone Phase ${safeZone.phase} locked.")
            }
        } else if (safeZone.isShrinking) {
            val shrinkProgress = (dt / safeZone.shrinkDurationSec)
            safeZone.currentRadius = (safeZone.currentRadius - (safeZone.currentRadius - safeZone.targetRadius) * shrinkProgress).coerceAtLeast(safeZone.targetRadius)
            safeZone.centerX += (safeZone.targetCenterX - safeZone.centerX) * shrinkProgress
            safeZone.centerZ += (safeZone.targetCenterZ - safeZone.centerZ) * shrinkProgress
        }

        // 2. Gloo Wall Cooldown & Decay
        var glooCooldown = max(0f, state.glooWallCooldownSec - dt)
        val currentTimeMs = System.currentTimeMillis()
        glooWalls.removeAll { wall ->
            currentTimeMs - wall.createdAt > 35000L || wall.health <= 0f
        }

        // 3. Zone Damage to all combatants outside
        combatants.forEach { c ->
            if (c.isAlive) {
                val distFromZone = c.position.distanceTo2D(Vec3(safeZone.centerX, 0f, safeZone.centerZ))
                if (distFromZone > safeZone.currentRadius) {
                    val dmg = safeZone.damagePerSec * dt
                    applyDamage(c, dmg, null, combatants, killFeed)
                }
            }
        }

        // 4. Update Bot AI
        updateBotsAI(dt, combatants, glooWalls, lootItems, safeZone, killFeed)

        // 5. Check Player Loot Pickup
        if (player.isAlive) {
            lootItems.forEach { item ->
                if (!item.isCollected && player.position.distanceTo2D(item.position) < 2.5f) {
                    item.isCollected = true
                    when (item.type) {
                        LootType.AMMO_AR -> player.currentWeaponState.reserveAmmo = min(player.currentWeapon.maxReserve, player.currentWeaponState.reserveAmmo + item.amount)
                        LootType.MEDKIT -> player.medkitsCount = min(5, player.medkitsCount + item.amount)
                        LootType.ARMOR_VEST -> player.armor = min(player.maxArmor, player.armor + 50f)
                        LootType.GLOO_WALL -> player.glooWallsCount = min(5, player.glooWallsCount + item.amount)
                        LootType.WEAPON_DROP -> item.associatedWeapon?.let { newWp ->
                            player.currentWeapon = newWp
                            player.currentWeaponState = WeaponState(newWp)
                            killFeed.add(0, "Picked up ${newWp.displayName}!")
                        }
                        else -> {}
                    }
                    soundManager.playMedkit()
                }
            }
        }

        // 6. Check Win/Loss conditions
        val aliveCombatants = combatants.filter { it.isAlive }
        val aliveCount = aliveCombatants.size

        var isGameOver = false
        var isVictory = false
        var matchResult: MatchResult? = null

        if (!player.isAlive) {
            isGameOver = true
            isVictory = false
            val placement = aliveCount + 1
            matchResult = calculateMatchResult(placement, combatants.size, player.kills, isVictory = false)
            recordProgressionAndSave(matchResult)
        } else if (aliveCount == 1 && aliveCombatants.first().isPlayer) {
            isGameOver = true
            isVictory = true
            soundManager.playVictory()
            matchResult = calculateMatchResult(1, combatants.size, player.kills, isVictory = true)
            recordProgressionAndSave(matchResult)
        }

        // Trim killfeed
        if (killFeed.size > 8) {
            killFeed.removeAt(killFeed.lastIndex)
        }

        // Muzzle flash fade
        val muzzleFlash = max(0f, state.muzzleFlashAlpha - dt * 6f)

        _gameState.value = state.copy(
            combatants = combatants,
            glooWalls = glooWalls,
            lootItems = lootItems,
            safeZone = safeZone,
            aliveCount = aliveCount,
            killFeed = killFeed,
            glooWallCooldownSec = glooCooldown,
            isGameOver = isGameOver,
            isVictory = isVictory,
            matchResult = matchResult,
            muzzleFlashAlpha = muzzleFlash,
            damageDirectionAngle = if (state.damageDirectionAngle != null) null else null
        )
    }

    private fun updateBotsAI(
        dt: Float,
        combatants: List<Combatant>,
        glooWalls: MutableList<GlooWall>,
        lootItems: List<LootItem>,
        safeZone: SafeZone,
        killFeed: MutableList<String>
    ) {
        val now = System.currentTimeMillis()
        val player = combatants.firstOrNull { it.isPlayer }

        combatants.filter { !it.isPlayer && it.isAlive }.forEach { bot ->
            // AI Reaction and navigation rate
            val distToSafeZoneCenter = bot.position.distanceTo2D(Vec3(safeZone.centerX, 0f, safeZone.centerZ))
            val isOutsideSafeZone = distToSafeZoneCenter > safeZone.currentRadius

            // Priority 1: Move towards safe zone if outside
            if (isOutsideSafeZone) {
                val targetX = safeZone.centerX
                val targetZ = safeZone.centerZ
                val angle = atan2(targetZ - bot.position.z, targetX - bot.position.x)
                bot.yaw = angle - (Math.PI / 2.0).toFloat()
                val moveSpeed = 4.2f * dt
                bot.position.x += cos(angle) * moveSpeed
                bot.position.z += sin(angle) * moveSpeed
            }

            // Priority 2: Health recovery if low and has medkit
            if (bot.health < 45f && bot.medkitsCount > 0 && now - bot.lastStateChangeTime > 3000L) {
                bot.botState = BotAIState.HEALING
                bot.medkitsCount -= 1
                bot.health = min(bot.maxHealth, bot.health + 40f)
                bot.lastStateChangeTime = now
            }

            // Priority 3: Find target (Player or other bots)
            var target: Combatant? = null
            if (player != null && player.isAlive && bot.position.distanceTo2D(player.position) < 45f) {
                target = player
            } else {
                // Target other nearby bots
                target = combatants.firstOrNull {
                    it.id != bot.id && it.isAlive && bot.position.distanceTo2D(it.position) < 30f
                }
            }

            if (target != null) {
                val dist = bot.position.distanceTo2D(target.position)
                val dirX = target.position.x - bot.position.x
                val dirZ = target.position.z - bot.position.z
                val targetYaw = atan2(dirZ, dirX) - (Math.PI / 2.0).toFloat()
                bot.yaw = targetYaw

                // Deploy Gloo Wall under heavy pressure
                if (bot.health < 40f && bot.glooWallsCount > 0 && Random.nextFloat() < selectedDifficulty.glooWallUseChance) {
                    bot.glooWallsCount -= 1
                    val wallPos = Vec3(
                        bot.position.x + sin(bot.yaw) * 3.5f,
                        0f,
                        bot.position.z + cos(bot.yaw) * 3.5f
                    )
                    glooWalls.add(GlooWall("gw_${bot.id}_$now", bot.id, wallPos, bot.yaw))
                    bot.botState = BotAIState.DEPLOYING_GLOO
                }

                // Movement & Flanking behavior
                if (dist > 15f) {
                    // Move closer
                    val speed = 3.8f * dt
                    bot.position.x += cos(targetYaw + (Math.PI / 2.0).toFloat()) * speed
                    bot.position.z += sin(targetYaw + (Math.PI / 2.0).toFloat()) * speed
                } else if (dist < 6f) {
                    // Back up or circle around
                    val strafeAngle = targetYaw + (Math.PI / 2.0).toFloat() + (if (Random.nextBoolean()) 1.57f else -1.57f)
                    val speed = 3.0f * dt
                    bot.position.x += cos(strafeAngle) * speed
                    bot.position.z += sin(strafeAngle) * speed
                }

                // Combat shooting with difficulty delay & accuracy check
                if (now - bot.lastShootAttemptTime > (bot.currentWeapon.fireRateMs + selectedDifficulty.reactionDelayMs)) {
                    bot.lastShootAttemptTime = now

                    // Check if gloo wall or obstacle blocks ray
                    val wallBlocks = glooWalls.any { gw ->
                        Engine3DMath.lineIntersectsCircle(bot.position.x, bot.position.z, target.position.x, target.position.z, gw.position.x, gw.position.z, 2.2f)
                    }

                    if (!wallBlocks) {
                        val isHit = Random.nextFloat() < selectedDifficulty.accuracy
                        if (isHit) {
                            val isHeadshot = Random.nextFloat() < 0.20f
                            val dmg = bot.currentWeapon.baseDamage * (if (isHeadshot) bot.currentWeapon.headshotMultiplier else 1.0f) * (0.85f + Random.nextFloat() * 0.3f)
                            applyDamage(target, dmg, bot, combatants, killFeed, isHeadshot)
                        }
                    }
                }
            } else {
                // Free roam / Loot patrol
                if (Random.nextFloat() < 0.03f) {
                    bot.yaw += (Random.nextFloat() - 0.5f) * 1.5f
                }
                val roamSpeed = 2.0f * dt
                val angle = bot.yaw + (Math.PI / 2.0).toFloat()
                bot.position.x = (bot.position.x + cos(angle) * roamSpeed).coerceIn(-BattleRoyaleMapData.MAP_HALF_SIZE + 5f, BattleRoyaleMapData.MAP_HALF_SIZE - 5f)
                bot.position.z = (bot.position.z + sin(angle) * roamSpeed).coerceIn(-BattleRoyaleMapData.MAP_HALF_SIZE + 5f, BattleRoyaleMapData.MAP_HALF_SIZE - 5f)
            }
        }
    }

    private fun applyDamage(
        target: Combatant,
        damage: Float,
        attacker: Combatant?,
        combatants: List<Combatant>,
        killFeed: MutableList<String>,
        isHeadshot: Boolean = false
    ) {
        if (!target.isAlive) return

        var remainingDmg = damage
        if (target.armor > 0f) {
            val armorDmg = min(target.armor, remainingDmg * 0.6f)
            target.armor -= armorDmg
            remainingDmg -= armorDmg * 0.5f
        }
        target.health = max(0f, target.health - remainingDmg)

        if (target.isPlayer) {
            soundManager.playHit(isHeadshot)
        }

        if (attacker?.isPlayer == true) {
            soundManager.playHit(isHeadshot)
            _gameState.value = _gameState.value.copy(
                recentHitmarker = HitmarkerEvent(damage, isHeadshot)
            )
        }

        if (target.health <= 0f) {
            target.isAlive = false
            target.botState = BotAIState.DEAD
            attacker?.kills = (attacker?.kills ?: 0) + 1
            val killerName = attacker?.name ?: "Safe Zone"
            val headshotTag = if (isHeadshot) " [HEADSHOT]" else ""
            killFeed.add(0, "$killerName eliminated ${target.name}$headshotTag")
        }
    }

    fun firePlayerWeapon(targetPitch: Float = 0f) {
        val state = _gameState.value
        val player = state.player
        if (!player.isAlive || player.currentWeaponState.isReloading) return

        val now = System.currentTimeMillis()
        if (now - player.currentWeaponState.lastFiredTime < player.currentWeapon.fireRateMs) return

        if (player.currentWeaponState.currentAmmo <= 0) {
            reloadPlayerWeapon()
            return
        }

        player.currentWeaponState.currentAmmo -= 1
        player.currentWeaponState.lastFiredTime = now
        soundManager.playGunfire(player.currentWeapon)

        // Calculate Raycast in facing direction
        val forwardX = sin(player.yaw)
        val forwardZ = cos(player.yaw)
        val maxDist = player.currentWeapon.effectiveRange

        // Raycast against Gloo Walls first
        val wallsHit = state.glooWalls.firstOrNull { gw ->
            Engine3DMath.lineIntersectsCircle(
                player.position.x, player.position.z,
                player.position.x + forwardX * maxDist, player.position.z + forwardZ * maxDist,
                gw.position.x, gw.position.z, 2.2f
            )
        }

        if (wallsHit != null) {
            wallsHit.health -= player.currentWeapon.baseDamage
            soundManager.playHit(false)
        } else {
            // Raycast against enemy combatants
            var nearestEnemy: Combatant? = null
            var nearestDist = Float.MAX_VALUE

            state.combatants.filter { !it.isPlayer && it.isAlive }.forEach { enemy ->
                val dist = player.position.distanceTo2D(enemy.position)
                if (dist < maxDist) {
                    val toEnemyX = enemy.position.x - player.position.x
                    val toEnemyZ = enemy.position.z - player.position.z
                    val enemyAngle = atan2(toEnemyX, toEnemyZ)
                    val angleDiff = abs(player.yaw - enemyAngle)
                    val tolerance = player.currentWeapon.spreadAngle + (if (player.isAimingADS) 0.05f else 0.12f)

                    if (angleDiff < tolerance && dist < nearestDist) {
                        nearestEnemy = enemy
                        nearestDist = dist
                    }
                }
            }

            if (nearestEnemy != null) {
                val isHeadshot = targetPitch > 0.08f || Random.nextFloat() < 0.25f
                val dmg = player.currentWeapon.baseDamage * (if (isHeadshot) player.currentWeapon.headshotMultiplier else 1.0f) * (0.9f + Random.nextFloat() * 0.2f)
                val killFeed = state.killFeed.toMutableList()
                applyDamage(nearestEnemy!!, dmg, player, state.combatants, killFeed, isHeadshot)
            }
        }

        _gameState.value = state.copy(
            muzzleFlashAlpha = 1.0f,
            player = player.copy(currentWeaponState = player.currentWeaponState)
        )
    }

    fun deployGlooWall() {
        val state = _gameState.value
        val player = state.player
        if (!player.isAlive || player.glooWallsCount <= 0 || state.glooWallCooldownSec > 0f) return

        player.glooWallsCount -= 1
        val forwardX = sin(player.yaw) * 3.2f
        val forwardZ = cos(player.yaw) * 3.2f

        val wallPos = Vec3(
            player.position.x + forwardX,
            0f,
            player.position.z + forwardZ
        )

        val newWall = GlooWall(
            id = "wall_${System.currentTimeMillis()}",
            ownerId = player.id,
            position = wallPos,
            yaw = player.yaw
        )

        soundManager.playGlooDeploy()

        _gameState.value = state.copy(
            glooWalls = state.glooWalls + newWall,
            glooWallCooldownSec = 2.5f,
            player = player
        )
    }

    fun useMedkit() {
        val player = _gameState.value.player
        if (!player.isAlive || player.medkitsCount <= 0 || player.health >= player.maxHealth) return

        player.medkitsCount -= 1
        player.health = min(player.maxHealth, player.health + 50f)
        soundManager.playMedkit()
        _gameState.value = _gameState.value.copy(player = player)
    }

    fun reloadPlayerWeapon() {
        val player = _gameState.value.player
        val wpState = player.currentWeaponState
        if (wpState.isReloading || wpState.currentAmmo >= wpState.type.magSize || wpState.reserveAmmo <= 0) return

        wpState.isReloading = true
        soundManager.playReload()

        viewModelScope.launch {
            delay(player.currentWeapon.reloadTimeMs)
            val needed = wpState.type.magSize - wpState.currentAmmo
            val toLoad = min(needed, wpState.reserveAmmo)
            wpState.currentAmmo += toLoad
            wpState.reserveAmmo -= toLoad
            wpState.isReloading = false
            _gameState.value = _gameState.value.copy(player = player)
        }
    }

    fun switchWeapon(newWeapon: WeaponType) {
        val player = _gameState.value.player
        if (player.currentWeapon == newWeapon) return
        player.currentWeapon = newWeapon
        player.currentWeaponState = WeaponState(newWeapon)
        soundManager.playReload()
        _gameState.value = _gameState.value.copy(player = player)
    }

    fun toggleADS() {
        val player = _gameState.value.player
        player.isAimingADS = !player.isAimingADS
        _gameState.value = _gameState.value.copy(player = player)
    }

    fun toggleCrouch() {
        val player = _gameState.value.player
        player.isCrouching = !player.isCrouching
        _gameState.value = _gameState.value.copy(player = player)
    }

    fun toggleSprint() {
        val player = _gameState.value.player
        player.isSprinting = !player.isSprinting
        _gameState.value = _gameState.value.copy(player = player)
    }

    fun movePlayer(moveX: Float, moveZ: Float, dt: Float = 0.033f) {
        val player = _gameState.value.player
        if (!player.isAlive) return

        val speed = if (player.isSprinting) 6.2f else if (player.isCrouching) 2.2f else 4.0f
        // Local to world orientation transform
        val cosY = cos(player.yaw)
        val sinY = sin(player.yaw)

        val worldDeltaX = (moveX * cosY + moveZ * sinY) * speed * dt
        val worldDeltaZ = (-moveX * sinY + moveZ * cosY) * speed * dt

        val nextX = (player.position.x + worldDeltaX).coerceIn(-BattleRoyaleMapData.MAP_HALF_SIZE + 2f, BattleRoyaleMapData.MAP_HALF_SIZE - 2f)
        val nextZ = (player.position.z + worldDeltaZ).coerceIn(-BattleRoyaleMapData.MAP_HALF_SIZE + 2f, BattleRoyaleMapData.MAP_HALF_SIZE - 2f)

        // Building collision
        val collidesWithBuilding = BattleRoyaleMapData.buildings.any { b ->
            b.contains(nextX, nextZ)
        }

        if (!collidesWithBuilding) {
            player.position.x = nextX
            player.position.z = nextZ
        }

        _gameState.value = _gameState.value.copy(player = player)
    }

    fun rotateCamera(deltaYaw: Float, deltaPitch: Float) {
        val player = _gameState.value.player
        val sens = if (player.isAimingADS) _controlSettings.value.adsSensitivity else _controlSettings.value.lookSensitivity
        player.yaw = (player.yaw + deltaYaw * sens * 0.006f) % (2.0f * Math.PI.toFloat())
        player.pitch = (player.pitch + deltaPitch * sens * 0.005f).coerceIn(-0.65f, 0.65f)
        _gameState.value = _gameState.value.copy(player = player)
    }

    private fun calculateMatchResult(placement: Int, total: Int, kills: Int, isVictory: Boolean): MatchResult {
        val gold = (if (isVictory) 850 else 250) + kills * 90 + (total - placement) * 20
        val diamonds = if (isVictory) 35 else if (placement <= 3) 15 else kills * 2
        val exp = (if (isVictory) 450 else 150) + kills * 60 + (total - placement) * 15

        return MatchResult(
            placement = placement,
            totalCombatants = total,
            kills = kills,
            damageDealt = kills * 110 + Random.nextInt(40, 180),
            survivalTimeSec = Random.nextInt(120, 360),
            goldEarned = gold,
            diamondsEarned = diamonds,
            expEarned = exp,
            isVictory = isVictory
        )
    }

    private fun recordProgressionAndSave(result: MatchResult) {
        val currentProg = _progression.value
        var newExp = currentProg.currentExp + result.expEarned
        var newLevel = currentProg.level
        var maxExp = currentProg.maxExp

        while (newExp >= maxExp) {
            newExp -= maxExp
            newLevel += 1
            maxExp = (maxExp * 1.25f).toInt()
        }

        _progression.value = currentProg.copy(
            level = newLevel,
            currentExp = newExp,
            maxExp = maxExp,
            goldBalance = currentProg.goldBalance + result.goldEarned,
            diamondBalance = currentProg.diamondBalance + result.diamondsEarned,
            matchesPlayed = currentProg.matchesPlayed + 1,
            matchesWon = currentProg.matchesWon + (if (result.isVictory) 1 else 0),
            totalKills = currentProg.totalKills + result.kills
        )

        savePersistedData()
    }

    // Shop & Cosmetics
    fun purchaseSkin(skin: CharacterSkin): Boolean {
        val prog = _progression.value
        if (prog.unlockedSkins.contains(skin.id)) return true

        if (skin.priceDiamonds > 0 && prog.diamondBalance >= skin.priceDiamonds) {
            _progression.value = prog.copy(
                diamondBalance = prog.diamondBalance - skin.priceDiamonds,
                unlockedSkins = prog.unlockedSkins + skin.id
            )
            savePersistedData()
            return true
        } else if (skin.priceGold > 0 && prog.goldBalance >= skin.priceGold) {
            _progression.value = prog.copy(
                goldBalance = prog.goldBalance - skin.priceGold,
                unlockedSkins = prog.unlockedSkins + skin.id
            )
            savePersistedData()
            return true
        }
        return false
    }

    fun equipSkin(skinId: String) {
        if (_progression.value.unlockedSkins.contains(skinId)) {
            _progression.value = _progression.value.copy(equippedSkinId = skinId)
            savePersistedData()
        }
    }

    fun claimMission(missionId: String) {
        val list = _missions.value.map { m ->
            if (m.id == missionId && !m.isClaimed && m.currentProgress >= m.targetProgress) {
                _progression.value = _progression.value.copy(
                    goldBalance = _progression.value.goldBalance + m.rewardGold,
                    diamondBalance = _progression.value.diamondBalance + m.rewardDiamonds
                )
                savePersistedData()
                m.copy(isClaimed = true)
            } else m
        }
        _missions.value = list
    }

    fun updateGraphicsSettings(newSettings: GraphicsSettings) {
        _graphicsSettings.value = newSettings
    }

    fun applyGraphicsPreset(preset: GraphicsPreset) {
        _graphicsSettings.value = GraphicsSettings(
            preset = preset,
            targetFps = preset.maxFps,
            resolutionScale = preset.resolutionScale,
            shadowsEnabled = preset.shadowsEnabled,
            bloomEnabled = preset.bloomEnabled,
            particleDensity = preset.particleDensity,
            renderDistance = preset.renderDistance
        )
    }

    fun updateAudioSettings(newSettings: AudioSettings) {
        _audioSettings.value = newSettings
        soundManager.sfxVolume = newSettings.sfxVolume
    }

    fun updateControlSettings(newSettings: ControlSettings) {
        _controlSettings.value = newSettings
    }

    fun endMatchAndReturnToLobby() {
        matchLoopJob?.cancel()
        _gameState.value = GameSessionState(isMatchActive = false)
    }

    override fun onCleared() {
        super.onCleared()
        matchLoopJob?.cancel()
        soundManager.release()
    }
}
