package com.example.engine

import kotlin.math.cos
import kotlin.math.sin

object Engine3DMath {

    data class Point3D(val x: Float, val y: Float, val z: Float)
    data class ScreenPoint(val x: Float, val y: Float, val depth: Float)

    /**
     * Projects a 3D world coordinate to 2D screen coordinate using camera position and rotation.
     * Camera yaw: around Y-axis (horizontal). Camera pitch: around X-axis (vertical).
     * Returns null if point is behind the camera.
     */
    fun projectWorldToScreen(
        worldX: Float,
        worldY: Float,
        worldZ: Float,
        camX: Float,
        camY: Float,
        camZ: Float,
        camYaw: Float,
        camPitch: Float,
        screenWidth: Float,
        screenHeight: Float,
        fovScale: Float = 1.15f
    ): ScreenPoint? {
        // Translation relative to camera
        val relX = worldX - camX
        val relY = worldY - camY
        val relZ = worldZ - camZ

        // Rotate by yaw (around Y)
        val cosY = cos(camYaw)
        val sinY = sin(camYaw)
        val x1 = relX * cosY - relZ * sinY
        val z1 = relX * sinY + relZ * cosY

        // Rotate by pitch (around X)
        val cosP = cos(camPitch)
        val sinP = sin(camPitch)
        val y2 = relY * cosP - z1 * sinP
        val z2 = relY * sinP + z1 * cosP

        // Near clipping plane check
        if (z2 <= 0.6f) return null

        val fov = (screenWidth * 0.5f) * fovScale
        val screenX = (screenWidth * 0.5f) + (x1 / z2) * fov
        val screenY = (screenHeight * 0.5f) - (y2 / z2) * fov

        return ScreenPoint(screenX, screenY, z2)
    }

    /**
     * Check if a 2D segment intersects a circle
     */
    fun lineIntersectsCircle(
        x1: Float, z1: Float,
        x2: Float, z2: Float,
        cx: Float, cz: Float,
        radius: Float
    ): Boolean {
        val dx = x2 - x1
        val dz = z2 - z1
        val lengthSq = dx * dx + dz * dz
        if (lengthSq < 0.0001f) return false

        val t = (((cx - x1) * dx + (cz - z1) * dz) / lengthSq).coerceIn(0f, 1f)
        val nearestX = x1 + t * dx
        val nearestZ = z1 + t * dz
        val distSq = (cx - nearestX) * (cx - nearestX) + (cz - nearestZ) * (cz - nearestZ)
        return distSq <= radius * radius
    }
}
