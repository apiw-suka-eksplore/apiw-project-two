package com.example.model

data class MapBuilding(
    val id: String,
    val name: String,
    val minX: Float,
    val maxX: Float,
    val minZ: Float,
    val maxZ: Float,
    val height: Float = 4.5f,
    val roofColor: Long = 0xFF475569,
    val wallColor: Long = 0xFF334155
) {
    fun contains(x: Float, z: Float): Boolean {
        return x in minX..maxX && z in minZ..maxZ
    }

    fun intersectsRay(x1: Float, z1: Float, x2: Float, z2: Float): Boolean {
        // Simple bounding box 2D ray intersection
        val minIntersectX = kotlin.math.min(x1, x2)
        val maxIntersectX = kotlin.math.max(x1, x2)
        val minIntersectZ = kotlin.math.min(z1, z2)
        val maxIntersectZ = kotlin.math.max(z1, z2)

        if (maxIntersectX < minX || minIntersectX > maxX || maxIntersectZ < minZ || minIntersectZ > maxZ) {
            return false
        }
        return true
    }
}

data class MapObstacle(
    val id: String,
    val position: Vec3,
    val radius: Float,
    val height: Float,
    val type: String // "tree", "rock", "crate"
)

object BattleRoyaleMapData {
    const val MAP_HALF_SIZE = 120f // 240m x 240m combat arena

    val buildings = listOf(
        // Central Military Command Post
        MapBuilding("b_center", "Central Outpost", -12f, 12f, -12f, 12f, 6.0f, 0xFF1E293B, 0xFF334155),
        // North Armory
        MapBuilding("b_north", "North Armory", -25f, -10f, -50f, -35f, 4.5f, 0xFF334155, 0xFF475569),
        // South Warehouse
        MapBuilding("b_south", "South Depot", 15f, 32f, 40f, 60f, 5.0f, 0xFF334155, 0xFF475569),
        // West Bunker
        MapBuilding("b_west", "West Watchpost", -55f, -38f, 10f, 25f, 4.0f, 0xFF1E293B, 0xFF334155),
        // East Hangar
        MapBuilding("b_east", "East Hangar", 45f, 65f, -20f, 0f, 5.5f, 0xFF334155, 0xFF64748B)
    )

    val obstacles = listOf(
        MapObstacle("obs_1", Vec3(18f, 0f, -15f), 1.8f, 2.2f, "crate"),
        MapObstacle("obs_2", Vec3(-18f, 0f, 20f), 2.2f, 2.5f, "rock"),
        MapObstacle("obs_3", Vec3(35f, 0f, 15f), 1.6f, 4.0f, "tree"),
        MapObstacle("obs_4", Vec3(-35f, 0f, -15f), 2.0f, 3.8f, "tree"),
        MapObstacle("obs_5", Vec3(5f, 0f, -40f), 2.5f, 2.0f, "rock"),
        MapObstacle("obs_6", Vec3(-45f, 0f, 45f), 1.8f, 4.2f, "tree"),
        MapObstacle("obs_7", Vec3(40f, 0f, -50f), 2.1f, 2.4f, "rock"),
        MapObstacle("obs_8", Vec3(-10f, 0f, 45f), 1.9f, 2.0f, "crate")
    )
}
