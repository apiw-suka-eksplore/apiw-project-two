package com.example.model

enum class WeaponType(
    val displayName: String,
    val fireRateMs: Long,
    val baseDamage: Float,
    val magSize: Int,
    val maxReserve: Int,
    val spreadAngle: Float,
    val recoilForce: Float,
    val reloadTimeMs: Long,
    val isAutomatic: Boolean,
    val pellets: Int = 1,
    val effectiveRange: Float = 60f,
    val headshotMultiplier: Float = 2.0f
) {
    AR("M4A1 Assault Rifle", 130L, 28f, 30, 180, 0.035f, 0.04f, 2000L, true, 1, 70f, 2.0f),
    SMG("MP5 Submachine", 90L, 19f, 35, 210, 0.065f, 0.025f, 1600L, true, 1, 40f, 1.8f),
    SHOTGUN("M1014 Shotgun", 750L, 14f, 6, 36, 0.12f, 0.12f, 2500L, false, 8, 22f, 1.75f),
    SNIPER("AWM Sniper Rifle", 1400L, 120f, 5, 20, 0.005f, 0.20f, 3000L, false, 1, 150f, 2.5f),
    PISTOL("Desert Eagle", 350L, 45f, 7, 42, 0.04f, 0.06f, 1400L, false, 1, 35f, 2.0f),
    KATANA("Cyber Katana", 450L, 65f, 1, 0, 0.2f, 0f, 0L, false, 1, 3.5f, 1.5f)
}

data class WeaponState(
    val type: WeaponType,
    var currentAmmo: Int = type.magSize,
    var reserveAmmo: Int = type.maxReserve,
    var isReloading: Boolean = false,
    var reloadProgress: Float = 0f,
    var lastFiredTime: Long = 0L
)

enum class CosmeticRarity(val label: String, val hexColor: Long) {
    COMMON("Standard", 0xFF94A3B8),
    RARE("Tactical Rare", 0xFF38BDF8),
    EPIC("Cyber Epic", 0xFFA855F7),
    LEGENDARY("Apex Legendary", 0xFFF59E0B)
}

data class CharacterSkin(
    val id: String,
    val name: String,
    val description: String,
    val rarity: CosmeticRarity,
    val primaryColor: Long, // Color int
    val secondaryColor: Long,
    val accentGlowColor: Long,
    val priceGold: Int = 0,
    val priceDiamonds: Int = 0,
    val isDefault: Boolean = false
)

data class WeaponSkin(
    val id: String,
    val weaponType: WeaponType,
    val name: String,
    val rarity: CosmeticRarity,
    val tintColor: Long,
    val emissiveColor: Long,
    val priceGold: Int = 0,
    val priceDiamonds: Int = 0,
    val isDefault: Boolean = false
)
