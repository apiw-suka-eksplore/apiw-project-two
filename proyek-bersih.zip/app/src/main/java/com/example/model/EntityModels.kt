package com.example.model

data class Vec3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) {
    fun distanceTo(other: Vec3): Float {
        val dx = x - other.x
        val dy = y - other.y
        val dz = z - other.z
        return kotlin.math.sqrt(dx * dx + dy * dy + dz * dz)
    }

    fun distanceTo2D(other: Vec3): Float {
        val dx = x - other.x
        val dz = z - other.z
        return kotlin.math.sqrt(dx * dx + dz * dz)
    }

    fun copy(): Vec3 = Vec3(x, y, z)
}

enum class BotAIState {
    PATROL,
    LOOTING,
    INVESTIGATING,
    ENGAGING,
    TAKING_COVER,
    FLANKING,
    HEALING,
    RETREATING,
    DEPLOYING_GLOO,
    DEAD
}

enum class BotDifficulty(
    val title: String,
    val accuracy: Float,
    val reactionDelayMs: Long,
    val fireRateMultiplier: Float,
    val glooWallUseChance: Float,
    val tacticalFlankChance: Float
) {
    EASY("Easy Cadet", 0.38f, 950L, 0.65f, 0.20f, 0.15f),
    NORMAL("Normal Soldier", 0.60f, 550L, 0.85f, 0.50f, 0.45f),
    HARD("Hard Veteran", 0.80f, 320L, 1.0f, 0.75f, 0.75f),
    EXTREME("Extreme Apex", 0.92f, 180L, 1.15f, 0.90f, 0.90f)
}

data class Combatant(
    val id: String,
    val name: String,
    val isPlayer: Boolean,
    var position: Vec3,
    var yaw: Float = 0f, // radians
    var pitch: Float = 0f,
    var health: Float = 100f,
    val maxHealth: Float = 100f,
    var armor: Float = 50f,
    val maxArmor: Float = 100f,
    var glooWallsCount: Int = 3,
    var medkitsCount: Int = 2,
    var currentWeapon: WeaponType = WeaponType.AR,
    var currentWeaponState: WeaponState = WeaponState(WeaponType.AR),
    var isAlive: Boolean = true,
    var kills: Int = 0,
    var isCrouching: Boolean = false,
    var isSprinting: Boolean = false,
    var isAimingADS: Boolean = false,
    var botState: BotAIState = BotAIState.PATROL,
    var botTargetId: String? = null,
    var botTargetLastKnownPos: Vec3? = null,
    var lastStateChangeTime: Long = 0L,
    var lastShootAttemptTime: Long = 0L,
    var characterSkinId: String = "skin_default",
    var currentAnimation: String = "idle"
)

enum class LootType {
    AMMO_AR,
    AMMO_SMG,
    AMMO_SHOTGUN,
    AMMO_SNIPER,
    MEDKIT,
    ARMOR_VEST,
    GLOO_WALL,
    WEAPON_DROP
}

data class LootItem(
    val id: String,
    val type: LootType,
    val position: Vec3,
    val amount: Int = 1,
    val associatedWeapon: WeaponType? = null,
    var isCollected: Boolean = false
)

data class GlooWall(
    val id: String,
    val ownerId: String,
    val position: Vec3,
    val yaw: Float,
    var health: Float = 250f,
    val maxHealth: Float = 250f,
    val createdAt: Long = System.currentTimeMillis()
)

data class SafeZone(
    var centerX: Float = 0f,
    var centerZ: Float = 0f,
    var currentRadius: Float = 160f,
    var targetRadius: Float = 120f,
    var targetCenterX: Float = 0f,
    var targetCenterZ: Float = 0f,
    var phase: Int = 1,
    var phaseDurationSec: Int = 45,
    var shrinkDurationSec: Int = 25,
    var timeRemainingSec: Float = 45f,
    var isShrinking: Boolean = false,
    var damagePerSec: Float = 4f
)

data class HitmarkerEvent(
    val damage: Float,
    val isHeadshot: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
