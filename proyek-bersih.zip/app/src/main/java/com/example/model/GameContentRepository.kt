package com.example.model

object GameContentRepository {

    val characterSkins = listOf(
        CharacterSkin(
            id = "skin_default",
            name = "Vanguard Ranger",
            description = "Standard frontline operative tactical armor",
            rarity = CosmeticRarity.COMMON,
            primaryColor = 0xFF334155, // slate
            secondaryColor = 0xFF0EA5E9, // cyan
            accentGlowColor = 0xFF38BDF8,
            priceGold = 0,
            priceDiamonds = 0,
            isDefault = true
        ),
        CharacterSkin(
            id = "skin_desert_commando",
            name = "Desert Marauder",
            description = "Sandstorm camouflaged assault specialist",
            rarity = CosmeticRarity.RARE,
            primaryColor = 0xFF78350F, // warm amber/brown
            secondaryColor = 0xFFF59E0B, // amber
            accentGlowColor = 0xFFFBBF24,
            priceGold = 1200,
            priceDiamonds = 0
        ),
        CharacterSkin(
            id = "skin_cyber_phantom",
            name = "Cyber Phantom",
            description = "High-tech stealth chassis with ultraviolet optical threads",
            rarity = CosmeticRarity.EPIC,
            primaryColor = 0xFF1E1B4B, // dark violet
            secondaryColor = 0xFFA855F7, // purple
            accentGlowColor = 0xFFC084FC,
            priceGold = 3500,
            priceDiamonds = 50
        ),
        CharacterSkin(
            id = "skin_apex_overlord",
            name = "Apex Titan Overlord",
            description = "Exoskeleton reinforced with golden plasma reactors",
            rarity = CosmeticRarity.LEGENDARY,
            primaryColor = 0xFF18181B, // obsidian
            secondaryColor = 0xFFEAB308, // apex gold
            accentGlowColor = 0xFFFACC15,
            priceGold = 7500,
            priceDiamonds = 120
        ),
        CharacterSkin(
            id = "skin_crimson_reaper",
            name = "Crimson Reaper",
            description = "Infiltrator suit pulsing with ruby bio-luminescence",
            rarity = CosmeticRarity.EPIC,
            primaryColor = 0xFF450A0A,
            secondaryColor = 0xFFEF4444,
            accentGlowColor = 0xFFF87171,
            priceGold = 4000,
            priceDiamonds = 65
        )
    )

    val weaponSkins = listOf(
        WeaponSkin("skin_ar_default", WeaponType.AR, "Standard Issue M4A1", CosmeticRarity.COMMON, 0xFF64748B, 0xFF94A3B8, 0, 0, true),
        WeaponSkin("skin_ar_tactical", WeaponType.AR, "M4A1 Desert Sand", CosmeticRarity.RARE, 0xFFD97706, 0xFFFCD34D, 800, 0),
        WeaponSkin("skin_ar_neon", WeaponType.AR, "M4A1 Cyber Wave", CosmeticRarity.EPIC, 0xFF8B5CF6, 0xFFA78BFA, 2200, 40),
        WeaponSkin("skin_smg_default", WeaponType.SMG, "Factory MP5", CosmeticRarity.COMMON, 0xFF475569, 0xFF64748B, 0, 0, true),
        WeaponSkin("skin_smg_volt", WeaponType.SMG, "MP5 High Voltage", CosmeticRarity.RARE, 0xFF0284C7, 0xFF38BDF8, 900, 0),
        WeaponSkin("skin_shotgun_default", WeaponType.SHOTGUN, "Steel M1014", CosmeticRarity.COMMON, 0xFF334155, 0xFF475569, 0, 0, true),
        WeaponSkin("skin_sniper_default", WeaponType.SNIPER, "AWM Arctic Camo", CosmeticRarity.COMMON, 0xFF0F172A, 0xFF38BDF8, 0, 0, true),
        WeaponSkin("skin_katana_default", WeaponType.KATANA, "Carbon Steel Katana", CosmeticRarity.COMMON, 0xFF1E293B, 0xFFEF4444, 0, 0, true)
    )

    val initialMissions = listOf(
        DailyMission("m1", "Combat Veteran", "Eliminate 5 opponents in offline battle royale", 3, 5, 500, 15),
        DailyMission("m2", "Tactical Barrier", "Deploy 3 Gloo Walls in combat", 2, 3, 350, 10),
        DailyMission("m3", "Apex Survivor", "Survive inside the Safe Zone for 3 minutes", 180, 180, 600, 20, isClaimed = true),
        DailyMission("m4", "Field Medic", "Use 2 Medkits while wounded", 1, 2, 400, 10)
    )
}
