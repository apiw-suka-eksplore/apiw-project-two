package com.example.model

enum class GraphicsPreset(
    val title: String,
    val description: String,
    val resolutionScale: Float,
    val maxFps: Int,
    val renderDistance: Float,
    val particleDensity: Float,
    val shadowsEnabled: Boolean,
    val bloomEnabled: Boolean
) {
    ULTRA_LOW("Ultra Low", "Maximum FPS on 1GB-2GB RAM phones, barebones rendering", 0.65f, 30, 75f, 0.2f, false, false),
    SUPER_SMOOTH("Super Smooth", "Optimized for budget 3GB RAM devices, steady 40 FPS", 0.75f, 40, 95f, 0.4f, false, false),
    SMOOTH("Smooth", "Great battery saver mode, stable 60 FPS", 0.85f, 60, 115f, 0.6f, false, false),
    BALANCED("Balanced", "Balanced visuals and performance default", 0.92f, 60, 135f, 0.75f, true, false),
    STANDARD("Standard", "Crisp resolution with dynamic shadows and foliage", 1.0f, 60, 160f, 0.85f, true, true),
    HIGH("High", "High-fidelity effects, long draw distances", 1.0f, 60, 190f, 1.0f, true, true),
    ULTRA("Ultra Apex", "Maximum visual density, 90 FPS on capable flagship screens", 1.0f, 90, 220f, 1.0f, true, true)
}

data class GraphicsSettings(
    val preset: GraphicsPreset = GraphicsPreset.BALANCED,
    val targetFps: Int = 60,
    val resolutionScale: Float = 0.92f,
    val shadowsEnabled: Boolean = true,
    val bloomEnabled: Boolean = false,
    val particleDensity: Float = 0.75f,
    val renderDistance: Float = 135f,
    val performanceMode: Boolean = false,
    val batterySaver: Boolean = false,
    val reducedEffects: Boolean = false
)

data class AudioSettings(
    val masterVolume: Float = 0.85f,
    val sfxVolume: Float = 0.90f,
    val musicVolume: Float = 0.60f
)

data class ControlSettings(
    val lookSensitivity: Float = 1.0f,
    val adsSensitivity: Float = 0.75f,
    val invertY: Boolean = false
)

data class PlayerProgression(
    val playerName: String = "Survivor #77",
    val level: Int = 4,
    val currentExp: Int = 640,
    val maxExp: Int = 1000,
    val goldBalance: Int = 3850,
    val diamondBalance: Int = 180,
    val matchesPlayed: Int = 14,
    val matchesWon: Int = 5,
    val totalKills: Int = 48,
    val equippedSkinId: String = "skin_default",
    val equippedWeaponSkinMap: Map<String, String> = mapOf("AR" to "skin_ar_default"),
    val unlockedSkins: Set<String> = setOf("skin_default", "skin_desert_commando"),
    val unlockedWeaponSkins: Set<String> = setOf("skin_ar_default", "skin_ar_tactical")
)

data class DailyMission(
    val id: String,
    val title: String,
    val description: String,
    val currentProgress: Int,
    val targetProgress: Int,
    val rewardGold: Int,
    val rewardDiamonds: Int,
    val isClaimed: Boolean = false
)

data class MatchResult(
    val placement: Int,
    val totalCombatants: Int,
    val kills: Int,
    val damageDealt: Int,
    val survivalTimeSec: Int,
    val goldEarned: Int,
    val diamondsEarned: Int,
    val expEarned: Int,
    val isVictory: Boolean
)
