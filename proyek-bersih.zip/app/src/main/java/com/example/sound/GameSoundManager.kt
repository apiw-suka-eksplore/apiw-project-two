package com.example.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class GameSoundManager(private val context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vm?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(8)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private var soundGunfire: Int = 0
    private var soundShotgun: Int = 0
    private var soundSniper: Int = 0
    private var soundReload: Int = 0
    private var soundGloo: Int = 0
    private var soundHit: Int = 0
    private var soundMedkit: Int = 0
    private var soundVictory: Int = 0

    var sfxVolume: Float = 0.9f

    init {
        try {
            soundGunfire = createSynthWav(frequency = 280, durationMs = 110, decay = 0.92f)
            soundShotgun = createSynthWav(frequency = 140, durationMs = 240, decay = 0.88f)
            soundSniper = createSynthWav(frequency = 440, durationMs = 280, decay = 0.94f)
            soundReload = createSynthWav(frequency = 520, durationMs = 150, decay = 0.85f)
            soundGloo = createSynthWav(frequency = 190, durationMs = 220, decay = 0.75f)
            soundHit = createSynthWav(frequency = 720, durationMs = 80, decay = 0.90f)
            soundMedkit = createSynthWav(frequency = 600, durationMs = 300, decay = 0.80f)
            soundVictory = createSynthWav(frequency = 880, durationMs = 500, decay = 0.96f)
        } catch (_: Exception) {
            // Audio synthesizer fallback
        }
    }

    private fun createSynthWav(frequency: Int, durationMs: Int, decay: Float): Int {
        val sampleRate = 22050
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
        val pcm = ShortArray(numSamples)
        var amplitude = 30000.0

        for (i in 0 until numSamples) {
            val angle = 2.0 * Math.PI * i / (sampleRate / frequency.toDouble())
            // Mix noise + sine for gunshot effect
            val sine = Math.sin(angle)
            val noise = (Math.random() * 2.0 - 1.0) * 0.4
            pcm[i] = ((sine * 0.6 + noise) * amplitude).toInt().coerceIn(-32767, 32767).toShort()
            amplitude *= decay
        }

        // Generate standard WAV header in temporary cache file
        val tempFile = File(context.cacheDir, "synth_${frequency}_${durationMs}.wav")
        val byteBuf = ByteBuffer.allocate(44 + numSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
        val dataSize = numSamples * 2
        val totalSize = 36 + dataSize

        byteBuf.put("RIFF".toByteArray())
        byteBuf.putInt(totalSize)
        byteBuf.put("WAVE".toByteArray())
        byteBuf.put("fmt ".toByteArray())
        byteBuf.putInt(16) // Subchunk1Size
        byteBuf.putShort(1) // PCM format
        byteBuf.putShort(1) // Mono
        byteBuf.putInt(sampleRate)
        byteBuf.putInt(sampleRate * 2) // ByteRate
        byteBuf.putShort(2) // BlockAlign
        byteBuf.putShort(16) // BitsPerSample
        byteBuf.put("data".toByteArray())
        byteBuf.putInt(dataSize)

        for (s in pcm) {
            byteBuf.putShort(s)
        }

        FileOutputStream(tempFile).use { it.write(byteBuf.array()) }
        return soundPool.load(tempFile.absolutePath, 1)
    }

    fun playGunfire(weapon: com.example.model.WeaponType) {
        val sound = when (weapon) {
            com.example.model.WeaponType.SHOTGUN -> soundShotgun
            com.example.model.WeaponType.SNIPER -> soundSniper
            else -> soundGunfire
        }
        if (sound != 0) soundPool.play(sound, sfxVolume, sfxVolume, 1, 0, 1.0f)
        vibrate(25)
    }

    fun playReload() {
        if (soundReload != 0) soundPool.play(soundReload, sfxVolume, sfxVolume, 1, 0, 1.0f)
    }

    fun playGlooDeploy() {
        if (soundGloo != 0) soundPool.play(soundGloo, sfxVolume, sfxVolume, 1, 0, 1.0f)
        vibrate(60)
    }

    fun playHit(isHeadshot: Boolean = false) {
        if (soundHit != 0) soundPool.play(soundHit, sfxVolume * (if (isHeadshot) 1.2f else 1.0f), sfxVolume, 1, 0, if (isHeadshot) 1.4f else 1.0f)
        vibrate(if (isHeadshot) 60 else 30)
    }

    fun playMedkit() {
        if (soundMedkit != 0) soundPool.play(soundMedkit, sfxVolume, sfxVolume, 1, 0, 1.0f)
    }

    fun playVictory() {
        if (soundVictory != 0) soundPool.play(soundVictory, sfxVolume, sfxVolume, 1, 0, 1.0f)
        vibrate(200)
    }

    private fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        soundPool.release()
    }
}
