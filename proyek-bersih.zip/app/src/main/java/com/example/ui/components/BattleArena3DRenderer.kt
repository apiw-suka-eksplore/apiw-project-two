package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.example.engine.Engine3DMath
import com.example.model.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BattleArena3DRenderer(
    player: Combatant,
    combatants: List<Combatant>,
    glooWalls: List<GlooWall>,
    lootItems: List<LootItem>,
    safeZone: SafeZone,
    graphicsSettings: GraphicsSettings,
    muzzleFlashAlpha: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val screenW = size.width
        val screenH = size.height

        // Camera calculations: Third person over-the-shoulder
        val camDist = if (player.isAimingADS) 1.5f else 2.8f
        val camHeight = if (player.isCrouching) 1.2f else 1.7f
        val shoulderOffset = if (player.isAimingADS) 0.45f else 0.70f

        val camYaw = player.yaw
        val camPitch = player.pitch

        // Camera position behind player shoulder
        val camX = player.position.x - sin(camYaw) * camDist + cos(camYaw) * shoulderOffset
        val camY = camHeight
        val camZ = player.position.z - cos(camYaw) * camDist - sin(camYaw) * shoulderOffset

        // 1. Sky & Horizon
        drawRect(
            color = Color(0xFF0F172A), // Dark tactical twilight sky
            size = Size(screenW, screenH)
        )

        // Horizon line calculation based on camera pitch
        val horizonY = (screenH * 0.5f) - (camPitch * screenH * 0.75f)
        if (horizonY in 0f..screenH) {
            drawRect(
                color = Color(0xFF1E293B),
                topLeft = Offset(0f, horizonY),
                size = Size(screenW, screenH - horizonY)
            )
        }

        // 2. Tactical Terrain Grid (Island Grounds)
        val gridStep = 8f
        val maxGridDist = graphicsSettings.renderDistance
        val playerGX = (player.position.x / gridStep).toInt() * gridStep
        val playerGZ = (player.position.z / gridStep).toInt() * gridStep

        var gx = playerGX - maxGridDist
        while (gx <= playerGX + maxGridDist) {
            var gz = playerGZ - maxGridDist
            while (gz <= playerGZ + maxGridDist) {
                // Project terrain block
                val p1 = Engine3DMath.projectWorldToScreen(gx, 0f, gz, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
                val p2 = Engine3DMath.projectWorldToScreen(gx + gridStep, 0f, gz, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
                val p3 = Engine3DMath.projectWorldToScreen(gx + gridStep, 0f, gz + gridStep, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
                val p4 = Engine3DMath.projectWorldToScreen(gx, 0f, gz + gridStep, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

                if (p1 != null && p2 != null && p3 != null && p4 != null) {
                    val tileColor = if (((gx / gridStep).toInt() + (gz / gridStep).toInt()) % 2 == 0) {
                        Color(0xFF1E293B)
                    } else {
                        Color(0xFF0F172A)
                    }
                    val path = Path().apply {
                        moveTo(p1.x, p1.y)
                        lineTo(p2.x, p2.y)
                        lineTo(p3.x, p3.y)
                        lineTo(p4.x, p4.y)
                        close()
                    }
                    drawPath(path, tileColor)
                }
                gz += gridStep * 2f
            }
            gx += gridStep * 2f
        }

        // 3. Render Safe Zone Dome Barrier
        drawSafeZoneDome(safeZone, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

        // 4. Render Buildings & Structures
        BattleRoyaleMapData.buildings.forEach { b ->
            drawBuilding3D(b, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        }

        // 5. Render Obstacles (Rocks, Crates, Trees)
        BattleRoyaleMapData.obstacles.forEach { obs ->
            drawObstacle3D(obs, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        }

        // 6. Render Loot Drops
        lootItems.filter { !it.isCollected }.forEach { loot ->
            drawLootItem3D(loot, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        }

        // 7. Render Gloo Walls (Defensive Shields)
        glooWalls.forEach { wall ->
            drawGlooWall3D(wall, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        }

        // 8. Render Combatants (Enemies & Bots)
        combatants.filter { !it.isPlayer && it.isAlive }.forEach { bot ->
            drawCombatant3D(bot, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        }

        // 9. Render Player Character Model (Over the shoulder)
        drawPlayerModel(player, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

        // 10. Muzzle Flash Effect
        if (muzzleFlashAlpha > 0.05f) {
            val flashX = screenW * 0.58f
            val flashY = screenH * 0.55f
            drawCircle(
                color = Color(0xFFFFB703).copy(alpha = muzzleFlashAlpha * 0.8f),
                radius = 32f,
                center = Offset(flashX, flashY)
            )
            drawCircle(
                color = Color(0xFFFFFFFF).copy(alpha = muzzleFlashAlpha),
                radius = 16f,
                center = Offset(flashX, flashY)
            )
        }
    }
}

private fun DrawScope.drawSafeZoneDome(
    safeZone: SafeZone,
    camX: Float, camY: Float, camZ: Float,
    camYaw: Float, camPitch: Float,
    screenW: Float, screenH: Float
) {
    val segments = 16
    for (i in 0 until segments) {
        val angle1 = (2.0 * Math.PI * i / segments).toFloat()
        val angle2 = (2.0 * Math.PI * (i + 1) / segments).toFloat()

        val x1 = safeZone.centerX + cos(angle1) * safeZone.currentRadius
        val z1 = safeZone.centerZ + sin(angle1) * safeZone.currentRadius
        val x2 = safeZone.centerX + cos(angle2) * safeZone.currentRadius
        val z2 = safeZone.centerZ + sin(angle2) * safeZone.currentRadius

        val p1 = Engine3DMath.projectWorldToScreen(x1, 0f, z1, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        val p2 = Engine3DMath.projectWorldToScreen(x2, 0f, z2, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        val pTop1 = Engine3DMath.projectWorldToScreen(x1, 12f, z1, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        val pTop2 = Engine3DMath.projectWorldToScreen(x2, 12f, z2, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

        if (p1 != null && p2 != null && pTop1 != null && pTop2 != null) {
            val path = Path().apply {
                moveTo(p1.x, p1.y)
                lineTo(p2.x, p2.y)
                lineTo(pTop2.x, pTop2.y)
                lineTo(pTop1.x, pTop1.y)
                close()
            }
            val zoneColor = if (safeZone.isShrinking) Color(0x33EF4444) else Color(0x330EA5E9)
            drawPath(path, zoneColor)
            drawLine(Color(0xFF38BDF8), Offset(p1.x, p1.y), Offset(p2.x, p2.y), strokeWidth = 3f)
        }
    }
}

private fun DrawScope.drawBuilding3D(
    b: MapBuilding,
    camX: Float, camY: Float, camZ: Float,
    camYaw: Float, camPitch: Float,
    screenW: Float, screenH: Float
) {
    val base1 = Engine3DMath.projectWorldToScreen(b.minX, 0f, b.minZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val base2 = Engine3DMath.projectWorldToScreen(b.maxX, 0f, b.minZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val base3 = Engine3DMath.projectWorldToScreen(b.maxX, 0f, b.maxZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val base4 = Engine3DMath.projectWorldToScreen(b.minX, 0f, b.maxZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

    val top1 = Engine3DMath.projectWorldToScreen(b.minX, b.height, b.minZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val top2 = Engine3DMath.projectWorldToScreen(b.maxX, b.height, b.minZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val top3 = Engine3DMath.projectWorldToScreen(b.maxX, b.height, b.maxZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val top4 = Engine3DMath.projectWorldToScreen(b.minX, b.height, b.maxZ, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

    if (top1 != null && top2 != null && top3 != null && top4 != null) {
        val roofPath = Path().apply {
            moveTo(top1.x, top1.y)
            lineTo(top2.x, top2.y)
            lineTo(top3.x, top3.y)
            lineTo(top4.x, top4.y)
            close()
        }
        drawPath(roofPath, Color(b.roofColor))
    }

    // Front/Side wall
    if (base1 != null && base2 != null && top2 != null && top1 != null) {
        val wallPath = Path().apply {
            moveTo(base1.x, base1.y)
            lineTo(base2.x, base2.y)
            lineTo(top2.x, top2.y)
            lineTo(top1.x, top1.y)
            close()
        }
        drawPath(wallPath, Color(b.wallColor))
    }
}

private fun DrawScope.drawObstacle3D(
    obs: MapObstacle,
    camX: Float, camY: Float, camZ: Float,
    camYaw: Float, camPitch: Float,
    screenW: Float, screenH: Float
) {
    val bottom = Engine3DMath.projectWorldToScreen(obs.position.x, 0f, obs.position.z, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val top = Engine3DMath.projectWorldToScreen(obs.position.x, obs.height, obs.position.z, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

    if (bottom != null && top != null) {
        val h = bottom.y - top.y
        val w = h * 0.7f
        val color = when (obs.type) {
            "tree" -> Color(0xFF15803D)
            "rock" -> Color(0xFF64748B)
            else -> Color(0xFFD97706)
        }
        drawRect(
            color = color,
            topLeft = Offset(bottom.x - w / 2, top.y),
            size = Size(w, h)
        )
    }
}

private fun DrawScope.drawGlooWall3D(
    wall: GlooWall,
    camX: Float, camY: Float, camZ: Float,
    camYaw: Float, camPitch: Float,
    screenW: Float, screenH: Float
) {
    val halfWidth = 2.2f
    val height = 2.6f
    val cosW = cos(wall.yaw + 1.57f) * halfWidth
    val sinW = sin(wall.yaw + 1.57f) * halfWidth

    val b1 = Engine3DMath.projectWorldToScreen(wall.position.x - cosW, 0f, wall.position.z - sinW, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val b2 = Engine3DMath.projectWorldToScreen(wall.position.x + cosW, 0f, wall.position.z + sinW, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val t1 = Engine3DMath.projectWorldToScreen(wall.position.x - cosW, height, wall.position.z - sinW, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val t2 = Engine3DMath.projectWorldToScreen(wall.position.x + cosW, height, wall.position.z + sinW, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

    if (b1 != null && b2 != null && t1 != null && t2 != null) {
        val wallPath = Path().apply {
            moveTo(b1.x, b1.y)
            lineTo(b2.x, b2.y)
            lineTo(t2.x, t2.y)
            lineTo(t1.x, t1.y)
            close()
        }
        // Holographic Glowing Energy Shield
        drawPath(wallPath, Color(0xCC0284C7))
        drawPath(wallPath, Color(0xFF38BDF8), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
    }
}

private fun DrawScope.drawLootItem3D(
    loot: LootItem,
    camX: Float, camY: Float, camZ: Float,
    camYaw: Float, camPitch: Float,
    screenW: Float, screenH: Float
) {
    val p = Engine3DMath.projectWorldToScreen(loot.position.x, 0.4f, loot.position.z, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    if (p != null) {
        val size = (16f / (p.depth * 0.15f)).coerceIn(8f, 26f)
        val color = when (loot.type) {
            LootType.MEDKIT -> Color(0xFF22C55E)
            LootType.ARMOR_VEST -> Color(0xFF3B82F6)
            LootType.GLOO_WALL -> Color(0xFF06B6D4)
            LootType.WEAPON_DROP -> Color(0xFFF59E0B)
            else -> Color(0xFFFBBF24)
        }
        drawCircle(color, radius = size, center = Offset(p.x, p.y))
        drawCircle(Color.White, radius = size * 0.4f, center = Offset(p.x, p.y))
    }
}

private fun DrawScope.drawCombatant3D(
    bot: Combatant,
    camX: Float, camY: Float, camZ: Float,
    camYaw: Float, camPitch: Float,
    screenW: Float, screenH: Float
) {
    val feet = Engine3DMath.projectWorldToScreen(bot.position.x, 0f, bot.position.z, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val head = Engine3DMath.projectWorldToScreen(bot.position.x, 1.8f, bot.position.z, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

    if (feet != null && head != null) {
        val h = feet.y - head.y
        val w = h * 0.45f
        if (h > 6f) {
            // Silhouette & Armor Body
            val skin = GameContentRepository.characterSkins.firstOrNull { it.id == bot.characterSkinId }
            val armorColor = Color(skin?.primaryColor ?: 0xFF475569)
            val visorColor = Color(skin?.accentGlowColor ?: 0xFF38BDF8)

            // Torso & legs
            drawRoundRect(
                color = armorColor,
                topLeft = Offset(head.x - w / 2, head.y),
                size = Size(w, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
            )

            // Helmet / Visor
            drawCircle(visorColor, radius = w * 0.22f, center = Offset(head.x, head.y + h * 0.18f))

            // Overhead Health Bar
            val barW = w * 1.2f
            val barH = 5f
            val healthPercent = (bot.health / bot.maxHealth).coerceIn(0f, 1f)
            drawRect(Color(0xFF334155), Offset(head.x - barW / 2, head.y - 12f), Size(barW, barH))
            drawRect(Color(0xFFEF4444), Offset(head.x - barW / 2, head.y - 12f), Size(barW * healthPercent, barH))
        }
    }
}

private fun DrawScope.drawPlayerModel(
    player: Combatant,
    camX: Float, camY: Float, camZ: Float,
    camYaw: Float, camPitch: Float,
    screenW: Float, screenH: Float
) {
    val feet = Engine3DMath.projectWorldToScreen(player.position.x, 0f, player.position.z, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
    val head = Engine3DMath.projectWorldToScreen(player.position.x, if (player.isCrouching) 1.2f else 1.8f, player.position.z, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

    if (feet != null && head != null) {
        val h = feet.y - head.y
        val w = h * 0.45f

        val skin = GameContentRepository.characterSkins.firstOrNull { it.id == player.characterSkinId }
        val armorColor = Color(skin?.primaryColor ?: 0xFF334155)
        val accentColor = Color(skin?.secondaryColor ?: 0xFF0EA5E9)

        // Draw Player Tactical Body
        drawRoundRect(
            color = armorColor,
            topLeft = Offset(head.x - w / 2, head.y),
            size = Size(w, h),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
        )

        // Tactical Backpack / Exoskeleton
        drawRect(accentColor, Offset(head.x - w * 0.35f, head.y + h * 0.25f), Size(w * 0.7f, h * 0.4f))

        // Visor glow
        drawCircle(Color(0xFF38BDF8), radius = w * 0.22f, center = Offset(head.x, head.y + h * 0.16f))
    }
}
