package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.GameSessionState
import com.example.model.WeaponType
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BattleHUD(
    gameState: GameSessionState,
    onMove: (Float, Float) -> Unit,
    onLook: (Float, Float) -> Unit,
    onFire: () -> Unit,
    onReload: () -> Unit,
    onSwitchWeapon: (WeaponType) -> Unit,
    onDeployGlooWall: () -> Unit,
    onUseMedkit: () -> Unit,
    onToggleADS: () -> Unit,
    onToggleCrouch: () -> Unit,
    onToggleSprint: () -> Unit,
    onPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    val player = gameState.player

    Box(modifier = modifier.fillMaxSize()) {

        // 1. Full Screen Camera Touch Drag Area (Right half)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onLook(dragAmount.x, dragAmount.y)
                    }
                }
        )

        // 2. Crosshair (Center)
        CrosshairView(
            isADS = player.isAimingADS,
            spreadFactor = player.currentWeapon.spreadAngle,
            recentHit = gameState.recentHitmarker != null && (System.currentTimeMillis() - gameState.recentHitmarker.timestamp < 250L),
            modifier = Modifier.align(Alignment.Center)
        )

        // 3. Top Bar (Survivors alive, Kills, Safe Zone timer)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Alive Combatants & Kills
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xCC0F172A))
                    .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Person, contentDescription = "Alive", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${gameState.aliveCount}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Icon(Icons.Default.SportsScore, contentDescription = "Kills", tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${player.kills}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            // Safe Zone Status Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (gameState.safeZone.isShrinking) Color(0xCCEF4444) else Color(0xCC0284C7))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Timer, contentDescription = "Safe Zone", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (gameState.safeZone.isShrinking) "SHRINKING: ${gameState.safeZone.timeRemainingSec.toInt()}s"
                    else "SAFE ZONE: ${gameState.safeZone.timeRemainingSec.toInt()}s",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }

            // Pause Menu Button
            IconButton(
                onClick = onPause,
                modifier = Modifier
                    .testTag("pause_match_button")
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xCC1E293B))
            ) {
                Icon(Icons.Default.Pause, contentDescription = "Pause", tint = Color.White)
            }
        }

        // 4. Kill Feed (Top Left under top bar)
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = 65.dp)
                .width(220.dp)
        ) {
            gameState.killFeed.take(4).forEach { feedMsg ->
                Text(
                    text = feedMsg,
                    color = Color(0xFFF1F5F9),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .padding(vertical = 2.dp)
                        .background(Color(0x990F172A), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        // 5. Mini-Map Radar (Top Right)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 16.dp, top = 65.dp)
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xCC0F172A))
                .border(1.5.dp, Color(0xFF38BDF8), CircleShape)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                // Player dot in center
                drawCircle(Color(0xFF38BDF8), radius = 4f, center = Offset(cx, cy))
                // Draw enemies within radar
                gameState.combatants.filter { !it.isPlayer && it.isAlive }.forEach { enemy ->
                    val dx = (enemy.position.x - player.position.x) * 0.45f
                    val dz = (enemy.position.z - player.position.z) * 0.45f
                    if (dx * dx + dz * dz < (cx - 4) * (cx - 4)) {
                        drawCircle(Color(0xFFEF4444), radius = 3.5f, center = Offset(cx + dx, cy + dz))
                    }
                }
            }
        }

        // 6. Virtual Joystick (Bottom Left)
        VirtualJoystick(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 32.dp, bottom = 36.dp)
                .testTag("virtual_joystick"),
            radiusDp = 64f,
            onMove = onMove
        )

        // 7. Tactical Controls Panel (Right Side: Fire, Gloo Wall, Medkit, Jump, ADS, Crouch)
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 24.dp, bottom = 24.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                // Secondary Tactical Actions Row: Gloo Wall & Medkit
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(bottom = 14.dp)
                ) {
                    // Gloo Wall Button
                    Button(
                        onClick = onDeployGlooWall,
                        modifier = Modifier
                            .testTag("gloo_wall_button")
                            .size(56.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (gameState.glooWallCooldownSec > 0f) Color(0xFF64748B) else Color(0xFF0284C7)
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Shield, contentDescription = "Gloo Wall", tint = Color.White, modifier = Modifier.size(20.dp))
                            Text(
                                text = if (gameState.glooWallCooldownSec > 0f) "${gameState.glooWallCooldownSec.toInt()}s" else "x${player.glooWallsCount}",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Medkit Button
                    Button(
                        onClick = onUseMedkit,
                        modifier = Modifier
                            .testTag("medkit_button")
                            .size(56.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.MedicalServices, contentDescription = "Medkit", tint = Color.White, modifier = Modifier.size(20.dp))
                            Text(text = "x${player.medkitsCount}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Aim ADS Button
                    Button(
                        onClick = onToggleADS,
                        modifier = Modifier
                            .testTag("ads_button")
                            .size(54.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (player.isAimingADS) Color(0xFFEAB308) else Color(0xCC334155)
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Adjust, contentDescription = "ADS Scope", tint = Color.White)
                    }
                }

                // Primary Combat Row: Crouch, Sprint, Reload, Main FIRE
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Crouch Button
                    IconButton(
                        onClick = onToggleCrouch,
                        modifier = Modifier
                            .testTag("crouch_button")
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (player.isCrouching) Color(0xFF38BDF8) else Color(0xCC1E293B))
                    ) {
                        Icon(Icons.Default.AirlineSeatReclineExtra, contentDescription = "Crouch", tint = Color.White)
                    }

                    // Sprint Button
                    IconButton(
                        onClick = onToggleSprint,
                        modifier = Modifier
                            .testTag("sprint_button")
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (player.isSprinting) Color(0xFFF59E0B) else Color(0xCC1E293B))
                    ) {
                        Icon(Icons.Default.DirectionsRun, contentDescription = "Sprint", tint = Color.White)
                    }

                    // Reload Button
                    Button(
                        onClick = onReload,
                        modifier = Modifier
                            .testTag("reload_button")
                            .size(50.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC334155)),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = Color.White)
                    }

                    // Prominent FIRE Button (Big Red Trigger)
                    Button(
                        onClick = onFire,
                        modifier = Modifier
                            .testTag("fire_button")
                            .size(80.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        contentPadding = PaddingValues(0.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        Icon(Icons.Default.GpsFixed, contentDescription = "FIRE", tint = Color.White, modifier = Modifier.size(38.dp))
                    }
                }
            }
        }

        // 8. Bottom Center: Player Health & Armor Bars, Weapon Selector
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Weapon Quick Selector Switcher
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xCC0F172A))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                listOf(WeaponType.AR, WeaponType.SMG, WeaponType.SHOTGUN, WeaponType.SNIPER).forEach { wp ->
                    val isSelected = player.currentWeapon == wp
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) Color(0xFF0284C7) else Color(0x66334155))
                            .border(1.dp, if (isSelected) Color(0xFF38BDF8) else Color.Transparent, RoundedCornerShape(6.dp))
                            .clickable { onSwitchWeapon(wp) }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = wp.name,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Ammo Counter & Weapon Name
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = player.currentWeapon.displayName,
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "${player.currentWeaponState.currentAmmo} / ${player.currentWeaponState.reserveAmmo}",
                    color = if (player.currentWeaponState.currentAmmo <= 5) Color(0xFFEF4444) else Color(0xFF38BDF8),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Armor Bar (Blue)
            Box(
                modifier = Modifier
                    .width(220.dp)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF1E293B))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(player.armor / player.maxArmor)
                        .background(Color(0xFF38BDF8))
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Health Bar (Green / Red)
            Box(
                modifier = Modifier
                    .width(220.dp)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF1E293B))
            ) {
                val hpRatio = (player.health / player.maxHealth).coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(hpRatio)
                        .background(if (hpRatio > 0.35f) Color(0xFF22C55E) else Color(0xFFDC2626))
                )
            }
        }
    }
}

@Composable
fun CrosshairView(
    isADS: Boolean,
    spreadFactor: Float,
    recentHit: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(48.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val spreadOffset = if (isADS) 6f else (10f + spreadFactor * 80f)
        val color = if (recentHit) Color(0xFFEF4444) else Color(0xDDFFFFFF)
        val lineLen = if (isADS) 6f else 8f

        // Top line
        drawLine(color, Offset(cx, cy - spreadOffset), Offset(cx, cy - spreadOffset - lineLen), strokeWidth = 2.5f)
        // Bottom line
        drawLine(color, Offset(cx, cy + spreadOffset), Offset(cx, cy + spreadOffset + lineLen), strokeWidth = 2.5f)
        // Left line
        drawLine(color, Offset(cx - spreadOffset, cy), Offset(cx - spreadOffset - lineLen, cy), strokeWidth = 2.5f)
        // Right line
        drawLine(color, Offset(cx + spreadOffset, cy), Offset(cx + spreadOffset + lineLen, cy), strokeWidth = 2.5f)

        // Center dot
        drawCircle(color, radius = 2f, center = Offset(cx, cy))
    }
}
