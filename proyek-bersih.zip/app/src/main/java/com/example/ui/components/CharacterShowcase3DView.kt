package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import com.example.engine.Engine3DMath
import com.example.model.CharacterSkin
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CharacterShowcase3DView(
    skin: CharacterSkin,
    rotationYaw: Float,
    onRotate: (deltaYaw: Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onRotate(dragAmount.x * 0.01f)
                }
            }
    ) {
        val screenW = size.width
        val screenH = size.height

        // Camera looking at showcase pedestal
        val camX = 0f
        val camY = 1.1f
        val camZ = -2.8f
        val camYaw = 0f
        val camPitch = 0.05f

        // 1. Draw glowing circular showcase pedestal
        val pedestalRadius = 1.2f
        val segments = 24
        val path = Path()
        for (i in 0..segments) {
            val angle = (2.0 * Math.PI * i / segments).toFloat()
            val px = cos(angle) * pedestalRadius
            val pz = sin(angle) * pedestalRadius
            val pt = Engine3DMath.projectWorldToScreen(px, 0f, pz, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
            if (pt != null) {
                if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
            }
        }
        drawPath(path, Color(0x331E293B))
        drawPath(path, Color(skin.accentGlowColor), style = Stroke(width = 3.5f))

        // 2. Character Model Center (at world origin) with rotationYaw
        val pFeet = Engine3DMath.projectWorldToScreen(0f, 0f, 0f, camX, camY, camZ, camYaw, camPitch, screenW, screenH)
        val pHead = Engine3DMath.projectWorldToScreen(0f, 1.85f, 0f, camX, camY, camZ, camYaw, camPitch, screenW, screenH)

        if (pFeet != null && pHead != null) {
            val modelH = pFeet.y - pHead.y
            val modelW = modelH * 0.42f
            val cx = pHead.x
            val cy = pHead.y

            // Tactical Armor Suit Body
            drawRoundRect(
                color = Color(skin.primaryColor),
                topLeft = Offset(cx - modelW / 2, cy),
                size = Size(modelW, modelH),
                cornerRadius = CornerRadius(14f, 14f)
            )

            // Accent Cyber plating
            drawRoundRect(
                color = Color(skin.secondaryColor),
                topLeft = Offset(cx - modelW * 0.35f, cy + modelH * 0.22f),
                size = Size(modelW * 0.7f, modelH * 0.45f),
                cornerRadius = CornerRadius(10f, 10f)
            )

            // Dynamic rotation offset for weapon holster and visor
            val visorOffsetX = sin(rotationYaw) * (modelW * 0.25f)
            val visorRadius = modelW * 0.20f

            // Helmet & Glowing Visor
            drawCircle(
                color = Color(0xFF0F172A),
                radius = visorRadius * 1.3f,
                center = Offset(cx + visorOffsetX * 0.5f, cy + modelH * 0.12f)
            )
            drawCircle(
                color = Color(skin.accentGlowColor),
                radius = visorRadius,
                center = Offset(cx + visorOffsetX, cy + modelH * 0.12f)
            )

            // Exoskeleton Kneepads & Boots
            drawRect(
                color = Color(skin.secondaryColor),
                topLeft = Offset(cx - modelW * 0.35f, cy + modelH * 0.75f),
                size = Size(modelW * 0.28f, modelH * 0.20f)
            )
            drawRect(
                color = Color(skin.secondaryColor),
                topLeft = Offset(cx + modelW * 0.07f, cy + modelH * 0.75f),
                size = Size(modelW * 0.28f, modelH * 0.20f)
            )
        }
    }
}
