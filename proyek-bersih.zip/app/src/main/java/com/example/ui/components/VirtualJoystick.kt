package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

@Composable
fun VirtualJoystick(
    modifier: Modifier = Modifier,
    radiusDp: Float = 60f,
    onMove: (normX: Float, normY: Float) -> Unit
) {
    var thumbOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .size((radiusDp * 2).dp)
            .clip(CircleShape)
            .background(Color(0x551E293B))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { },
                    onDragEnd = {
                        thumbOffset = Offset.Zero
                        onMove(0f, 0f)
                    },
                    onDragCancel = {
                        thumbOffset = Offset.Zero
                        onMove(0f, 0f)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newPos = thumbOffset + dragAmount
                        val dist = newPos.getDistance()
                        val maxRadiusPx = radiusDp * density

                        if (dist > maxRadiusPx) {
                            val angle = atan2(newPos.y, newPos.x)
                            thumbOffset = Offset(cos(angle) * maxRadiusPx, sin(angle) * maxRadiusPx)
                        } else {
                            thumbOffset = newPos
                        }

                        val normX = (thumbOffset.x / maxRadiusPx).coerceIn(-1f, 1f)
                        val normY = (-thumbOffset.y / maxRadiusPx).coerceIn(-1f, 1f) // up is forward (+Z)
                        onMove(normX, normY)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // Outer ring indicator
        Box(
            modifier = Modifier
                .size((radiusDp * 1.8f).dp)
                .clip(CircleShape)
                .background(Color(0x3338BDF8))
        )

        // Joystick Thumb
        Box(
            modifier = Modifier
                .offset { IntOffset(thumbOffset.x.toInt(), thumbOffset.y.toInt()) }
                .size(46.dp)
                .clip(CircleShape)
                .background(Color(0xFF38BDF8))
        )
    }
}
