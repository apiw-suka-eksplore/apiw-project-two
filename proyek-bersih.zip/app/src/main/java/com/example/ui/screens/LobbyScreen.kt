package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BotDifficulty
import com.example.model.GameContentRepository
import com.example.model.PlayerProgression
import com.example.ui.components.CharacterShowcase3DView

@Composable
fun LobbyScreen(
    progression: PlayerProgression,
    onStartMatch: (botCount: Int, difficulty: BotDifficulty) -> Unit,
    onOpenShop: () -> Unit,
    onOpenMissions: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showcaseRotation by remember { mutableStateOf(0f) }
    var selectedBots by remember { mutableStateOf(19) }
    var selectedDifficulty by remember { mutableStateOf(BotDifficulty.NORMAL) }
    var showMatchSetupDialog by remember { mutableStateOf(false) }

    val equippedSkin = GameContentRepository.characterSkins.firstOrNull { it.id == progression.equippedSkinId }
        ?: GameContentRepository.characterSkins.first()

    Box(modifier = modifier.fillMaxSize().background(Color(0xFF090D16))) {

        // Hero Background Artwork Layer
        Image(
            painter = painterResource(id = R.drawable.img_battle_hero_1791593293114),
            contentDescription = "Battle Royale Background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.38f
        )

        // Gradient overlay for contrast
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xEE090D16), Color(0x77090D16), Color(0xF0090D16))
                    )
                )
        )

        // 3D Character Showcase Pedestal in Center
        CharacterShowcase3DView(
            skin = equippedSkin,
            rotationYaw = showcaseRotation,
            onRotate = { delta -> showcaseRotation += delta },
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 70.dp)
        )

        // Top Navigation Bar: Profile, Currencies, Settings
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Player Profile Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xCC0F172A))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(24.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0284C7)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "LV.${progression.level}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = progression.playerName,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "EXP: ${progression.currentExp}/${progression.maxExp}",
                        color = Color(0xFF94A3B8),
                        fontSize = 10.sp
                    )
                }
            }

            // Currency & Settings Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Gold Balance
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xCC0F172A))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.MonetizationOn, contentDescription = "Gold", tint = Color(0xFFEAB308), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "${progression.goldBalance}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // Diamonds Balance
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xCC0F172A))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Diamond, contentDescription = "Diamonds", tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "${progression.diamondBalance}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                // Settings Icon Button
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .testTag("lobby_settings_button")
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xCC1E293B))
                ) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                }
            }
        }

        // Left Action Rail (Missions, Shop, Armory, Stats)
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LobbyRailButton(
                icon = Icons.Default.Storefront,
                label = "VAULT SHOP",
                tag = "lobby_shop_button",
                onClick = onOpenShop
            )
            LobbyRailButton(
                icon = Icons.Default.Assignment,
                label = "MISSIONS",
                tag = "lobby_missions_button",
                onClick = onOpenMissions
            )
        }

        // Right Stats Summary Card
        Card(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp)
                .width(140.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xCC0F172A)),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x4438BDF8))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(text = "CAREER STATS", color = Color(0xFF38BDF8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Matches: ${progression.matchesPlayed}", color = Color.White, fontSize = 11.sp)
                Text(text = "Victories: ${progression.matchesWon}", color = Color(0xFFEAB308), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Text(text = "Kills: ${progression.totalKills}", color = Color(0xFFEF4444), fontSize = 11.sp)
                val kd = if (progression.matchesPlayed > 0) String.format("%.2f", progression.totalKills.toFloat() / progression.matchesPlayed) else "0.00"
                Text(text = "K/D: $kd", color = Color(0xFF94A3B8), fontSize = 10.sp)
            }
        }

        // Bottom Prominent Play Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Mode & Bot Config Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xCC0F172A))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
                    .clickable { showMatchSetupDialog = true }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Column {
                    Text(text = "SOLO BATTLE ROYALE", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "19 Bots • ${selectedDifficulty.title}",
                        color = Color(0xFF38BDF8),
                        fontSize = 11.sp
                    )
                }
            }

            // Big Action PLAY BUTTON
            Button(
                onClick = { onStartMatch(selectedBots, selectedDifficulty) },
                modifier = Modifier
                    .testTag("start_match_button")
                    .height(58.dp)
                    .width(180.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(28.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "DEPLOY", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }

        // Match Config Modal
        if (showMatchSetupDialog) {
            AlertDialog(
                onDismissRequest = { showMatchSetupDialog = false },
                title = { Text("Match Configuration", color = Color.White, fontWeight = FontWeight.Bold) },
                containerColor = Color(0xFF0F172A),
                text = {
                    Column {
                        Text("Bot Count: $selectedBots", color = Color(0xFF94A3B8), fontSize = 12.sp)
                        Slider(
                            value = selectedBots.toFloat(),
                            onValueChange = { selectedBots = it.toInt() },
                            valueRange = 5f..35f,
                            steps = 5,
                            colors = SliderDefaults.colors(thumbColor = Color(0xFF38BDF8), activeTrackColor = Color(0xFF0284C7))
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Bot Difficulty:", color = Color(0xFF94A3B8), fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(6.dp))

                        BotDifficulty.values().forEach { diff ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedDifficulty = diff }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = selectedDifficulty == diff,
                                    onClick = { selectedDifficulty = diff },
                                    colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF38BDF8))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(diff.title, color = Color.White, fontSize = 13.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showMatchSetupDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                    ) {
                        Text("Confirm")
                    }
                }
            )
        }
    }
}

@Composable
private fun LobbyRailButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tag: String,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .testTag(tag)
            .width(130.dp)
            .height(44.dp),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC1E293B)),
        contentPadding = PaddingValues(horizontal = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = label, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}
