package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*

@Composable
fun SettingsScreen(
    graphicsSettings: GraphicsSettings,
    audioSettings: AudioSettings,
    controlSettings: ControlSettings,
    onApplyPreset: (GraphicsPreset) -> Unit,
    onUpdateGraphics: (GraphicsSettings) -> Unit,
    onUpdateAudio: (AudioSettings) -> Unit,
    onUpdateControls: (ControlSettings) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(scrollState)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .testTag("settings_back_button")
                        .clip(CircleShape)
                        .background(Color(0xCC1E293B))
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(14.dp))
                Text("GAME & GRAPHICS SETTINGS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // SECTION 1: GRAPHICS PRESETS
            Text("PERFORMANCE & GRAPHICS PRESETS", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GraphicsPreset.values().forEach { preset ->
                    val isSelected = graphicsSettings.preset == preset
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onApplyPreset(preset) },
                        colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF0F172A) else Color(0xCC1E293B)),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) Color(0xFF38BDF8) else Color(0x22FFFFFF)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(preset.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(preset.description, color = Color(0xFF94A3B8), fontSize = 10.sp)
                            }
                            Text("${preset.maxFps} FPS", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SECTION 2: FRAME-RATE & LOW-END TOGGLES
            Text("DEVICE OPTIMIZATIONS", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xCC1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Battery Saver
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Battery Saver Mode", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("Throttles background calculations", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        }
                        Switch(
                            checked = graphicsSettings.batterySaver,
                            onCheckedChange = { onUpdateGraphics(graphicsSettings.copy(batterySaver = it)) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Shadows
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Real-Time Terrain Shadows", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("Disable for older GPUs to increase smoothness", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        }
                        Switch(
                            checked = graphicsSettings.shadowsEnabled,
                            onCheckedChange = { onUpdateGraphics(graphicsSettings.copy(shadowsEnabled = it)) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SECTION 3: CONTROLS & SENSITIVITY
            Text("CONTROL SENSITIVITY", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xCC1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Camera Look Sensitivity: ${(controlSettings.lookSensitivity * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                    Slider(
                        value = controlSettings.lookSensitivity,
                        onValueChange = { onUpdateControls(controlSettings.copy(lookSensitivity = it)) },
                        valueRange = 0.4f..2.5f
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("ADS Scope Sensitivity: ${(controlSettings.adsSensitivity * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                    Slider(
                        value = controlSettings.adsSensitivity,
                        onValueChange = { onUpdateControls(controlSettings.copy(adsSensitivity = it)) },
                        valueRange = 0.2f..1.8f
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SECTION 4: AUDIO VOLUMES
            Text("AUDIO & SOUND FX", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xCC1E293B)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Sound Effects (Gunfire, Hits): ${(audioSettings.sfxVolume * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                    Slider(
                        value = audioSettings.sfxVolume,
                        onValueChange = { onUpdateAudio(audioSettings.copy(sfxVolume = it)) },
                        valueRange = 0f..1f
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Master Volume: ${(audioSettings.masterVolume * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                    Slider(
                        value = audioSettings.masterVolume,
                        onValueChange = { onUpdateAudio(audioSettings.copy(masterVolume = it)) },
                        valueRange = 0f..1f
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
