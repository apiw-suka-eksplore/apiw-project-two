package com.example

import com.example.model.BotDifficulty
import com.example.model.GameContentRepository
import com.example.model.PlayerProgression
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class ExampleRobolectricTest {

    @Test
    fun testProgressionAndSkinCatalog() {
        val skins = GameContentRepository.characterSkins
        assertTrue(skins.isNotEmpty())
        val defaultSkin = skins.first { it.isDefault }
        assertEquals("skin_default", defaultSkin.id)

        val player = PlayerProgression(level = 1, currentExp = 0)
        assertEquals(1, player.level)
        assertTrue(player.unlockedSkins.contains("skin_default"))
    }

    @Test
    fun testBotDifficulties() {
        val normal = BotDifficulty.NORMAL
        val hard = BotDifficulty.HARD
        val extreme = BotDifficulty.EXTREME

        assertTrue(hard.accuracy > normal.accuracy)
        assertTrue(extreme.reactionDelayMs < hard.reactionDelayMs)
    }
}
