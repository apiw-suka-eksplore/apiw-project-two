package com.example

import com.example.model.*
import org.junit.Assert.*
import org.junit.Test

class BattleRoyaleUnitTest {

    @Test
    fun testCombatMathAndDistance() {
        val posA = Vec3(0f, 0f, 0f)
        val posB = Vec3(3f, 4f, 0f)
        assertEquals(5f, posA.distanceTo(posB), 0.001f)
        assertEquals(3f, posA.distanceTo2D(Vec3(3f, 10f, 0f)), 0.001f)
    }

    @Test
    fun testWeaponRosterAndBalance() {
        val ar = WeaponType.AR
        assertEquals(30, ar.magSize)
        assertTrue(ar.baseDamage > 20f)
        assertTrue(ar.effectiveRange >= 50f)

        val sniper = WeaponType.SNIPER
        assertTrue(sniper.baseDamage >= 100f)
        assertEquals(2.5f, sniper.headshotMultiplier, 0.01f)

        val shotgun = WeaponType.SHOTGUN
        assertEquals(8, shotgun.pellets)
    }

    @Test
    fun testSafeZoneInitialConfiguration() {
        val zone = SafeZone()
        assertEquals(160f, zone.currentRadius, 0.01f)
        assertEquals(1, zone.phase)
        assertFalse(zone.isShrinking)
    }

    @Test
    fun testMapBoundsAndObstacles() {
        assertTrue(BattleRoyaleMapData.buildings.isNotEmpty())
        assertTrue(BattleRoyaleMapData.obstacles.isNotEmpty())

        val centralOutpost = BattleRoyaleMapData.buildings.first { it.id == "b_center" }
        assertTrue(centralOutpost.contains(0f, 0f))
        assertFalse(centralOutpost.contains(50f, 50f))
    }
}
